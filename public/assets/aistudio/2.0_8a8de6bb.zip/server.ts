import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';

import { config } from './server/config';
import { errorHandler } from './server/middleware/errorHandler';
import { healthRouter } from './server/routes/health.routes';
import { authRouter } from './server/routes/auth.routes';
import { agentsRouter } from './server/routes/agents.routes';
import { tasksRouter } from './server/routes/tasks.routes';
import { benchmarksRouter } from './server/routes/benchmarks.routes';
import { leaderboardRouter } from './server/routes/leaderboard.routes';
import { analyticsRouter } from './server/routes/analytics.routes';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();

  // Basic Middleware
  app.use(cors());
  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true }));

  // API Routes
  const apiRouter = express.Router();
  apiRouter.use('/health', healthRouter);
  apiRouter.use('/auth', authRouter);
  apiRouter.use('/agents', agentsRouter);
  apiRouter.use('/tasks', tasksRouter);
  apiRouter.use('/benchmarks', benchmarksRouter);
  apiRouter.use('/leaderboard', leaderboardRouter);
  apiRouter.use('/analytics', analyticsRouter);

  app.use('/api', apiRouter);

  // Error handling for API routes
  app.use('/api', errorHandler);

  // Mount Vite development middlewares or serve static assets
  if (config.nodeEnv !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  const port = config.port;
  app.listen(port, '0.0.0.0', () => {
    console.log(`[AgentArena] Server running on http://0.0.0.0:${port}`);
    console.log(`[AgentArena] REST API mounted at /api`);
  });
}

startServer().catch((err) => {
  console.error('[AgentArena] Failed to start server:', err);
  process.exit(1);
});
