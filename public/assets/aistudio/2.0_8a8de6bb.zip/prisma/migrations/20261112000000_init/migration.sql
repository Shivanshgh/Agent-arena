-- CreateEnum
CREATE TYPE "UserRole" AS ENUM ('ADMIN', 'DEVELOPER', 'VIEWER');

-- CreateEnum
CREATE TYPE "IntegrationType" AS ENUM ('HTTP_WEBHOOK', 'DOCKER_CONTAINER', 'BIFROST_GATEWAY');

-- CreateEnum
CREATE TYPE "AgentStatus" AS ENUM ('READY', 'BUSY', 'OFFLINE', 'ERROR');

-- CreateEnum
CREATE TYPE "TaskCategory" AS ENUM ('BUG_FIXING', 'ALGORITHMIC', 'SYSTEM_REFACTOR', 'SECURITY', 'DATABASE');

-- CreateEnum
CREATE TYPE "TaskDifficulty" AS ENUM ('EASY', 'MEDIUM', 'HARD', 'SWE_BENCH');

-- CreateEnum
CREATE TYPE "RunStatus" AS ENUM ('QUEUED', 'RUNNING', 'COMPLETED', 'FAILED');

-- CreateEnum
CREATE TYPE "ExecutionStatus" AS ENUM ('PENDING', 'RUNNING', 'COMPLETED', 'FAILED', 'TIMEOUT');

-- CreateEnum
CREATE TYPE "ReportFormat" AS ENUM ('MARKDOWN', 'JSON', 'CSV');

-- CreateTable
CREATE TABLE "users" (
    "id" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "name" TEXT,
    "role" "UserRole" NOT NULL DEFAULT 'DEVELOPER',
    "apiKeyHash" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "users_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "agents" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "version" TEXT NOT NULL DEFAULT '1.0.0',
    "description" TEXT NOT NULL,
    "integrationType" "IntegrationType" NOT NULL DEFAULT 'HTTP_WEBHOOK',
    "endpointUrl" TEXT NOT NULL,
    "authorId" TEXT NOT NULL,
    "baseModel" TEXT NOT NULL,
    "capabilities" TEXT[] DEFAULT ARRAY['file_edit', 'terminal_exec', 'test_runner']::TEXT[],
    "supportedLanguages" TEXT[] DEFAULT ARRAY['python', 'typescript']::TEXT[],
    "status" "AgentStatus" NOT NULL DEFAULT 'READY',
    "avgScore" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "totalRuns" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "agents_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "agent_versions" (
    "id" TEXT NOT NULL,
    "agentId" TEXT NOT NULL,
    "versionTag" TEXT NOT NULL,
    "changelog" TEXT,
    "endpointUrl" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "agent_versions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "tasks" (
    "id" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "category" "TaskCategory" NOT NULL DEFAULT 'BUG_FIXING',
    "difficulty" "TaskDifficulty" NOT NULL DEFAULT 'MEDIUM',
    "language" TEXT NOT NULL DEFAULT 'python',
    "description" TEXT NOT NULL,
    "starterCode" TEXT NOT NULL,
    "referenceSolution" TEXT,
    "testCasesJson" JSONB NOT NULL,
    "timeLimitSec" INTEGER NOT NULL DEFAULT 120,
    "memoryLimitMb" INTEGER NOT NULL DEFAULT 512,
    "createdById" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "tasks_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "benchmark_suites" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "taskIds" TEXT[],
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "benchmark_suites_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "benchmark_runs" (
    "id" TEXT NOT NULL,
    "taskId" TEXT NOT NULL,
    "status" "RunStatus" NOT NULL DEFAULT 'QUEUED',
    "startedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "completedAt" TIMESTAMP(3),
    "scoringWeights" JSONB NOT NULL,
    "winnerAgentId" TEXT,
    "summary" TEXT,

    CONSTRAINT "benchmark_runs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "executions" (
    "id" TEXT NOT NULL,
    "benchmarkRunId" TEXT NOT NULL,
    "agentId" TEXT NOT NULL,
    "status" "ExecutionStatus" NOT NULL DEFAULT 'PENDING',
    "durationMs" INTEGER NOT NULL DEFAULT 0,
    "inputTokens" INTEGER NOT NULL DEFAULT 0,
    "outputTokens" INTEGER NOT NULL DEFAULT 0,
    "totalTokens" INTEGER NOT NULL DEFAULT 0,
    "estimatedCostUsd" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "memoryUsedMb" INTEGER NOT NULL DEFAULT 0,
    "testsPassed" INTEGER NOT NULL DEFAULT 0,
    "totalTests" INTEGER NOT NULL DEFAULT 0,
    "deterministicPassRate" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "generatedCode" TEXT,
    "unifiedDiff" TEXT,
    "stdoutLogs" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "stderrLogs" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "executions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "evaluation_results" (
    "id" TEXT NOT NULL,
    "executionId" TEXT NOT NULL,
    "overallScore" DOUBLE PRECISION NOT NULL,
    "accuracySubscore" DOUBLE PRECISION NOT NULL,
    "completionSubscore" DOUBLE PRECISION NOT NULL,
    "reliabilitySubscore" DOUBLE PRECISION NOT NULL,
    "speedSubscore" DOUBLE PRECISION NOT NULL,
    "costSubscore" DOUBLE PRECISION NOT NULL,
    "breakdownSummary" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "evaluation_results_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "agent_metrics" (
    "id" TEXT NOT NULL,
    "agentId" TEXT NOT NULL,
    "totalRuns" INTEGER NOT NULL DEFAULT 0,
    "avgScore" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "overallAccuracy" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "avgDurationSec" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "completionRate" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "reliabilityRate" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "costEfficiency" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "agent_metrics_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "reports" (
    "id" TEXT NOT NULL,
    "benchmarkRunId" TEXT NOT NULL,
    "format" "ReportFormat" NOT NULL DEFAULT 'MARKDOWN',
    "content" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "reports_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "users_email_key" ON "users"("email");

-- CreateIndex
CREATE INDEX "agents_authorId_idx" ON "agents"("authorId");

-- CreateIndex
CREATE INDEX "agents_status_idx" ON "agents"("status");

-- CreateIndex
CREATE INDEX "agent_versions_agentId_idx" ON "agent_versions"("agentId");

-- CreateIndex
CREATE UNIQUE INDEX "agent_versions_agentId_versionTag_key" ON "agent_versions"("agentId", "versionTag");

-- CreateIndex
CREATE INDEX "tasks_category_idx" ON "tasks"("category");

-- CreateIndex
CREATE INDEX "tasks_difficulty_idx" ON "tasks"("difficulty");

-- CreateIndex
CREATE INDEX "benchmark_runs_taskId_idx" ON "benchmark_runs"("taskId");

-- CreateIndex
CREATE INDEX "benchmark_runs_status_idx" ON "benchmark_runs"("status");

-- CreateIndex
CREATE INDEX "benchmark_runs_startedAt_idx" ON "benchmark_runs"("startedAt");

-- CreateIndex
CREATE INDEX "executions_benchmarkRunId_idx" ON "executions"("benchmarkRunId");

-- CreateIndex
CREATE INDEX "executions_agentId_idx" ON "executions"("agentId");

-- CreateIndex
CREATE UNIQUE INDEX "evaluation_results_executionId_key" ON "evaluation_results"("executionId");

-- CreateIndex
CREATE UNIQUE INDEX "agent_metrics_agentId_key" ON "agent_metrics"("agentId");

-- CreateIndex
CREATE INDEX "reports_benchmarkRunId_idx" ON "reports"("benchmarkRunId");

-- AddForeignKey
ALTER TABLE "agents" ADD CONSTRAINT "agents_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "agent_versions" ADD CONSTRAINT "agent_versions_agentId_fkey" FOREIGN KEY ("agentId") REFERENCES "agents"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "tasks" ADD CONSTRAINT "tasks_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "benchmark_runs" ADD CONSTRAINT "benchmark_runs_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES "tasks"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "executions" ADD CONSTRAINT "executions_benchmarkRunId_fkey" FOREIGN KEY ("benchmarkRunId") REFERENCES "benchmark_runs"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "executions" ADD CONSTRAINT "executions_agentId_fkey" FOREIGN KEY ("agentId") REFERENCES "agents"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "evaluation_results" ADD CONSTRAINT "evaluation_results_executionId_fkey" FOREIGN KEY ("executionId") REFERENCES "executions"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "agent_metrics" ADD CONSTRAINT "agent_metrics_agentId_fkey" FOREIGN KEY ("agentId") REFERENCES "agents"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "reports" ADD CONSTRAINT "reports_benchmarkRunId_fkey" FOREIGN KEY ("benchmarkRunId") REFERENCES "benchmark_runs"("id") ON DELETE CASCADE ON UPDATE CASCADE;
