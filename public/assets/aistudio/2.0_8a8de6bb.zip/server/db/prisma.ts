import { PrismaClient } from '@prisma/client';
import { config } from '../config';
import { encryptSecret } from '../security/crypto';

declare global {
  // eslint-disable-next-line no-var
  var _prismaInstance: PrismaClient | undefined;
}

let prisma: PrismaClient | null = null;
let isPostgresConnected = false;

// Attempt initializing Prisma if DATABASE_URL is provided
if (config.databaseUrl && config.databaseUrl.trim() !== '') {
  try {
    if (!global._prismaInstance) {
      global._prismaInstance = new PrismaClient({
        datasources: {
          db: {
            url: config.databaseUrl,
          },
        },
        log: config.nodeEnv === 'development' ? ['warn', 'error'] : ['error'],
      });
    }
    prisma = global._prismaInstance;
  } catch (err) {
    console.warn('[Prisma] Could not initialize PrismaClient with current DATABASE_URL:', err);
    prisma = null;
  }
}

// In-Memory Storage Layer for graceful dev execution & seed persistence
interface InMemoryStore {
  agents: any[];
  tasks: any[];
  benchmarkRuns: any[];
  agentMetrics: Record<string, any>;
}

const memoryStore: InMemoryStore = {
  agents: [
    {
      id: 'agent_devin_24',
      name: 'Devin-v2.4',
      version: '2.4.1',
      description: 'Autonomous software engineering agent with deep code search, AST reasoning, and recursive test validation.',
      integrationType: 'HTTP_WEBHOOK',
      endpointUrl: 'https://agent-gateway.devin.ai/v1/benchmarks/execute',
      author: 'Cognition Labs',
      authorId: 'usr_cognition',
      createdAt: '2026-08-14T00:00:00Z',
      status: 'READY',
      capabilities: ['file_edit', 'terminal_exec', 'git_branching', 'test_runner', 'multi_file_reasoning'],
      supportedLanguages: ['python', 'typescript', 'go', 'rust', 'java'],
      baseModel: 'Claude 3.7 Sonnet / Reasoning',
      avgScore: 89.4,
      totalRuns: 64,
    },
    {
      id: 'agent_swe_pro',
      name: 'SWE-Agent Pro',
      version: '1.9.0',
      description: 'Specialized agent configured with custom ACI (Agent-Computer Interface) designed for SWE-bench verified tasks.',
      integrationType: 'HTTP_WEBHOOK',
      endpointUrl: 'https://swe-runner.princeton.edu/api/v2/evaluate',
      author: 'SWE-Bench Team',
      authorId: 'usr_princeton',
      createdAt: '2026-07-22T00:00:00Z',
      status: 'READY',
      capabilities: ['file_edit', 'terminal_exec', 'patch_generation', 'linter_eval'],
      supportedLanguages: ['python', 'typescript', 'c++'],
      baseModel: 'GPT-4.5 Preview',
      avgScore: 86.8,
      totalRuns: 58,
    },
    {
      id: 'agent_openhands',
      name: 'OpenHands-v0.18',
      version: '0.18.3',
      description: 'Community-driven open platform agent using containerized workspace sandboxing and modular skill planning.',
      integrationType: 'DOCKER_CONTAINER',
      endpointUrl: 'http://localhost:5000/api/openhands/dispatch',
      author: 'All-Hands AI',
      authorId: 'usr_allhands',
      createdAt: '2026-09-01T00:00:00Z',
      status: 'READY',
      capabilities: ['file_edit', 'terminal_exec', 'browser_eval', 'docker_sandbox', 'test_runner'],
      supportedLanguages: ['python', 'typescript', 'go', 'ruby'],
      baseModel: 'Gemini 3.8 Flash / Carbon',
      avgScore: 83.2,
      totalRuns: 49,
    },
    {
      id: 'agent_aider_arch',
      name: 'Aider-Architect',
      version: '0.45.0',
      description: 'Pair programming & autonomous refactoring specialist emphasizing strict git commits, minimal diff footprint, and high cost efficiency.',
      integrationType: 'HTTP_WEBHOOK',
      endpointUrl: 'https://api.aider.chat/v1/agent/run',
      author: 'Paul Gauthier',
      authorId: 'usr_aider',
      createdAt: '2026-06-10T00:00:00Z',
      status: 'READY',
      capabilities: ['file_edit', 'git_branching', 'cost_optimizer', 'linter_eval'],
      supportedLanguages: ['python', 'typescript', 'rust', 'go', 'javascript'],
      baseModel: 'Claude 3.5 Haiku + Sonnet Fallback',
      avgScore: 84.6,
      totalRuns: 72,
    },
    {
      id: 'agent_cursor_auto',
      name: 'Cursor-Agent-Runner',
      version: '0.9.4',
      description: 'Ultra-low latency agent leveraging incremental codebase indexing, fast shadow edits, and speculative code transformations.',
      integrationType: 'HTTP_WEBHOOK',
      endpointUrl: 'https://agent.cursor.com/api/v1/execute',
      author: 'Anysphere',
      authorId: 'usr_anysphere',
      createdAt: '2026-10-05T00:00:00Z',
      status: 'READY',
      capabilities: ['file_edit', 'terminal_exec', 'codebase_indexing', 'fast_inference'],
      supportedLanguages: ['typescript', 'python', 'rust', 'go'],
      baseModel: 'Cursor Tab Engine v3',
      avgScore: 81.9,
      totalRuns: 41,
    },
  ],
  tasks: [
    {
      id: 'task_rate_limiter_race',
      title: 'Fix Concurrency Race Condition in Distributed Rate Limiter',
      category: 'BUG_FIXING',
      difficulty: 'HARD',
      language: 'python',
      description: 'A Redis-backed sliding window rate limiter intermittently allows 12-18% burst traffic over the configured limit during concurrent async worker execution. Identify the non-atomic check-then-set race condition and refactor using an atomic Lua script or atomic pipeline script.',
      starterCode: `import time\n\nclass SlidingWindowLimiter:\n    def __init__(self, redis_client, max_requests: int, window_seconds: int):\n        self.redis = redis_client\n        self.max_requests = max_requests\n        self.window_seconds = window_seconds\n\n    async def is_allowed(self, client_id: str) -> bool:\n        # BUG: Non-atomic window check allows concurrent coroutines to bypass limit\n        current_time = time.time()\n        window_start = current_time - self.window_seconds\n        key = f"rate_limit:{client_id}"\n        await self.redis.zremrangebyscore(key, 0, window_start)\n        count = await self.redis.zcard(key)\n        if count >= self.max_requests:\n            return False\n        await self.redis.zadd(key, {str(current_time): current_time})\n        await self.redis.expire(key, self.window_seconds)\n        return True\n`,
      referenceSolution: `import time\n\nLUA_SCRIPT = """\nlocal key, now, window, limit = KEYS[1], tonumber(ARGV[1]), tonumber(ARGV[2]), tonumber(ARGV[3])\nredis.call('ZREMRANGEBYSCORE', key, 0, now - window)\nif redis.call('ZCARD', key) < limit then\n    redis.call('ZADD', key, now, now)\n    redis.call('EXPIRE', key, math.ceil(window))\n    return 1\nend\nreturn 0\n"""\n`,
      testCases: [
        { id: 'tc_1', name: 'Single Thread Within Quota', input: 'requests=10, limit=10, window=60', expectedOutput: 'All allowed', isSecret: false, timeoutMs: 1500 },
        { id: 'tc_2', name: 'Single Thread Exceed Quota', input: 'requests=15, limit=10, window=60', expectedOutput: '5 rejected', isSecret: false, timeoutMs: 1500 },
        { id: 'tc_3', name: 'High Concurrency 50 Async Workers', input: 'concurrent_workers=50, limit=20', expectedOutput: 'Exactly 20 allowed', isSecret: false, timeoutMs: 4000 },
        { id: 'tc_4', name: 'Window Expiration & Reset', input: 'sleep=window+0.1', expectedOutput: 'Refreshed', isSecret: true, timeoutMs: 3000 },
      ],
      timeLimitSec: 180,
      memoryLimitMb: 512,
      createdAt: '2026-10-15T00:00:00Z',
    },
    {
      id: 'task_lru_cache_ttl',
      title: 'Implement LRU Cache with TTL Eviction & O(1) Operations',
      category: 'ALGORITHMIC',
      difficulty: 'MEDIUM',
      language: 'typescript',
      description: 'Implement an in-memory Least Recently Used (LRU) Cache in TypeScript that supports strict O(1) get() and put() amortized time complexity, capacity eviction, and passive TTL expiration for stale entries.',
      starterCode: `export class TTLLRUCache<K, V> {\n  constructor(private capacity: number, private defaultTtlMs?: number) {}\n  get(key: K): V | undefined { return undefined; }\n  put(key: K, value: V, ttlMs?: number): void {}\n  size(): number { return 0; }\n}\n`,
      testCases: [
        { id: 'tc_lru_1', name: 'Capacity Eviction of LRU Key', input: 'cap=2; put(1,1); put(2,2); get(1); put(3,3)', expectedOutput: 'get(2) is undefined', isSecret: false, timeoutMs: 1000 },
        { id: 'tc_lru_2', name: 'TTL Expiration Invalidation', input: 'put(a, 100, ttl=50); wait(60); get(a)', expectedOutput: 'get(a) is undefined', isSecret: false, timeoutMs: 1500 },
      ],
      timeLimitSec: 120,
      memoryLimitMb: 256,
      createdAt: '2026-10-18T00:00:00Z',
    },
  ],
  benchmarkRuns: [
    {
      id: 'run_2026_1101_01',
      taskId: 'task_rate_limiter_race',
      taskTitle: 'Fix Concurrency Race Condition in Distributed Rate Limiter',
      taskCategory: 'BUG_FIXING',
      startedAt: '2026-11-10T14:22:10Z',
      completedAt: '2026-11-10T14:25:34Z',
      status: 'COMPLETED',
      agents: ['agent_devin_24', 'agent_swe_pro', 'agent_aider_arch'],
      winnerAgentId: 'agent_devin_24',
      summary: 'Devin-v2.4 solved the concurrency race with an atomic Redis Lua script passing 100% of the 50-worker concurrency tests in 42.1s with minimal token overhead.',
      scoringWeights: { accuracy: 40, taskCompletion: 25, reliability: 15, speed: 10, costEfficiency: 10 },
      executions: {
        agent_devin_24: {
          id: 'exec_d24_01',
          agentId: 'agent_devin_24',
          agentName: 'Devin-v2.4',
          agentVersion: '2.4.1',
          status: 'COMPLETED',
          metrics: { durationMs: 42100, inputTokens: 3840, outputTokens: 780, totalTokens: 4620, estimatedCostUsd: 0.024, testsPassed: 4, totalTests: 4, deterministicPassRate: 100 },
          evaluationScore: { overall: 93.4, accuracySubscore: 40.0, completionSubscore: 25.0, reliabilitySubscore: 15.0, speedSubscore: 8.4, costSubscore: 5.0, breakdownExplanation: '100% tests passed' },
        },
      },
    },
  ],
  agentMetrics: {},
};

export const dbService = {
  getPrismaClient(): PrismaClient | null {
    return prisma;
  },

  async checkDatabaseHealth(): Promise<{
    connected: boolean;
    provider: 'postgresql' | 'memory_fallback';
    error?: string;
  }> {
    if (prisma) {
      try {
        await prisma.$queryRaw`SELECT 1`;
        isPostgresConnected = true;
        return { connected: true, provider: 'postgresql' };
      } catch (err: any) {
        return {
          connected: false,
          provider: 'memory_fallback',
          error: err.message || 'PostgreSQL connection failed. Using memory repository.',
        };
      }
    }

    return {
      connected: true,
      provider: 'memory_fallback',
      error: 'DATABASE_URL not configured. Operating in high-performance in-memory repository mode.',
    };
  },

  // Agent Operations
  async listAgents(): Promise<any[]> {
    if (prisma && isPostgresConnected) {
      try {
        return await prisma.agent.findMany({
          orderBy: { createdAt: 'desc' },
          include: { metrics: true },
        });
      } catch (err) {
        console.warn('[Prisma] Fallback to memory store for listAgents:', err);
      }
    }
    return memoryStore.agents;
  },

  async getAgentById(id: string): Promise<any | null> {
    if (prisma && isPostgresConnected) {
      try {
        return await prisma.agent.findUnique({
          where: { id },
          include: { versions: true, metrics: true },
        });
      } catch (err) {
        console.warn('[Prisma] Fallback to memory store for getAgentById:', err);
      }
    }
    return memoryStore.agents.find((a) => a.id === id) || null;
  },

  async createAgent(data: any): Promise<any> {
    let authConfigStored = data.authConfig || { type: 'NONE' };
    if (authConfigStored && authConfigStored.token) {
      authConfigStored = {
        type: authConfigStored.type || 'BEARER_TOKEN',
        encryptedToken: encryptSecret(authConfigStored.token),
        headerName: authConfigStored.headerName,
      };
    }

    const newAgent = {
      id: `agent_${Date.now()}`,
      name: data.name,
      version: data.version || '1.0.0',
      description: data.description,
      integrationType: data.integrationType || 'HTTP_WEBHOOK',
      endpointUrl: data.endpointUrl,
      healthEndpoint: data.healthEndpoint || '/health',
      author: data.author || 'Local Developer',
      authorId: 'usr_default_dev',
      baseModel: data.baseModel || 'Custom LLM',
      capabilities: data.capabilities || ['file_edit', 'terminal_exec', 'test_runner'],
      supportedLanguages: data.supportedLanguages || ['python', 'typescript'],
      status: data.status || 'READY',
      authConfig: authConfigStored,
      lastConnectedAt: data.lastConnectedAt || null,
      metadata: data.metadata || {},
      avgScore: 0,
      totalRuns: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    if (prisma && isPostgresConnected) {
      try {
        const { authorId: _aId, ...agentFields } = newAgent;
        return await (prisma.agent.create as any)({
          data: {
            ...agentFields,
            author: {
              connectOrCreate: {
                where: { email: 'developer@agentarena.internal' },
                create: { email: 'developer@agentarena.internal', name: 'Dev User' },
              },
            },
          },
        });
      } catch (err) {
        console.warn('[Prisma] Fallback to memory store for createAgent:', err);
      }
    }

    memoryStore.agents.unshift(newAgent);
    return newAgent;
  },

  async updateAgent(id: string, data: any): Promise<any | null> {
    const updatePayload = { ...data };
    if (updatePayload.authConfig && updatePayload.authConfig.token) {
      updatePayload.authConfig = {
        type: updatePayload.authConfig.type,
        encryptedToken: encryptSecret(updatePayload.authConfig.token),
        headerName: updatePayload.authConfig.headerName,
      };
    }

    if (prisma && isPostgresConnected) {
      try {
        return await prisma.agent.update({
          where: { id },
          data: { ...updatePayload, updatedAt: new Date() },
        });
      } catch (err) {
        console.warn('[Prisma] Fallback to memory store for updateAgent:', err);
      }
    }

    const idx = memoryStore.agents.findIndex((a) => a.id === id);
    if (idx === -1) return null;
    memoryStore.agents[idx] = { ...memoryStore.agents[idx], ...updatePayload, updatedAt: new Date().toISOString() };
    return memoryStore.agents[idx];
  },

  async updateAgentConnectionStatus(id: string, status: string, lastConnectedAt?: string): Promise<any | null> {
    const timestamp = lastConnectedAt || new Date().toISOString();
    return await this.updateAgent(id, { status, lastConnectedAt: timestamp });
  },

  async deleteAgent(id: string): Promise<boolean> {
    if (prisma && isPostgresConnected) {
      try {
        await prisma.agent.delete({ where: { id } });
        return true;
      } catch (err) {
        console.warn('[Prisma] Fallback to memory store for deleteAgent:', err);
      }
    }

    const initialLen = memoryStore.agents.length;
    memoryStore.agents = memoryStore.agents.filter((a) => a.id !== id);
    return memoryStore.agents.length < initialLen;
  },

  // Task Operations
  async listTasks(category?: string, difficulty?: string): Promise<any[]> {
    if (prisma && isPostgresConnected) {
      try {
        const where: any = {};
        if (category && category !== 'all') where.category = category.toUpperCase();
        if (difficulty && difficulty !== 'all') where.difficulty = difficulty.toUpperCase();
        return await prisma.task.findMany({
          where,
          orderBy: { createdAt: 'desc' },
        });
      } catch (err) {
        console.warn('[Prisma] Fallback to memory store for listTasks:', err);
      }
    }

    return memoryStore.tasks.filter((t) => {
      const matchCat = !category || category === 'all' || t.category.toLowerCase() === category.toLowerCase();
      const matchDiff = !difficulty || difficulty === 'all' || t.difficulty.toLowerCase() === difficulty.toLowerCase();
      return matchCat && matchDiff;
    });
  },

  async getTaskById(id: string): Promise<any | null> {
    if (prisma && isPostgresConnected) {
      try {
        return await prisma.task.findUnique({ where: { id } });
      } catch (err) {
        console.warn('[Prisma] Fallback to memory store for getTaskById:', err);
      }
    }
    return memoryStore.tasks.find((t) => t.id === id) || null;
  },

  async createTask(data: any): Promise<any> {
    const newTask = {
      id: `task_${Date.now()}`,
      title: data.title,
      category: (data.category || 'BUG_FIXING').toUpperCase(),
      difficulty: (data.difficulty || 'MEDIUM').toUpperCase(),
      language: data.language || 'python',
      description: data.description,
      starterCode: data.starterCode,
      referenceSolution: data.referenceSolution || null,
      testCases: data.testCases || [],
      timeLimitSec: data.timeLimitSec || 120,
      memoryLimitMb: data.memoryLimitMb || 512,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    if (prisma && isPostgresConnected) {
      try {
        return await prisma.task.create({
          data: {
            ...newTask,
            testCasesJson: newTask.testCases as any,
          },
        });
      } catch (err) {
        console.warn('[Prisma] Fallback to memory store for createTask:', err);
      }
    }

    memoryStore.tasks.unshift(newTask);
    return newTask;
  },

  async deleteTask(id: string): Promise<boolean> {
    if (prisma && isPostgresConnected) {
      try {
        await prisma.task.delete({ where: { id } });
        return true;
      } catch (err) {
        console.warn('[Prisma] Fallback to memory store for deleteTask:', err);
      }
    }

    const initLen = memoryStore.tasks.length;
    memoryStore.tasks = memoryStore.tasks.filter((t) => t.id !== id);
    return memoryStore.tasks.length < initLen;
  },

  // Benchmark Run Operations
  async listRuns(): Promise<any[]> {
    if (prisma && isPostgresConnected) {
      try {
        return await prisma.benchmarkRun.findMany({
          orderBy: { startedAt: 'desc' },
          include: { task: true, executions: { include: { evaluationResult: true } } },
        });
      } catch (err) {
        console.warn('[Prisma] Fallback to memory store for listRuns:', err);
      }
    }
    return memoryStore.benchmarkRuns;
  },

  async getRunById(id: string): Promise<any | null> {
    if (prisma && isPostgresConnected) {
      try {
        return await prisma.benchmarkRun.findUnique({
          where: { id },
          include: { task: true, executions: { include: { evaluationResult: true } } },
        });
      } catch (err) {
        console.warn('[Prisma] Fallback to memory store for getRunById:', err);
      }
    }
    return memoryStore.benchmarkRuns.find((r) => r.id === id) || null;
  },

  async createRun(data: any): Promise<any> {
    const newRun = {
      id: `run_${Date.now()}`,
      taskId: data.taskId,
      taskTitle: data.taskTitle || 'Challenge',
      taskCategory: data.taskCategory || 'BUG_FIXING',
      startedAt: new Date().toISOString(),
      completedAt: data.completedAt || new Date().toISOString(),
      status: data.status || 'COMPLETED',
      agents: data.agents || [],
      executions: data.executions || {},
      scoringWeights: data.scoringWeights || { accuracy: 40, taskCompletion: 25, reliability: 15, speed: 10, costEfficiency: 10 },
      winnerAgentId: data.winnerAgentId,
      summary: data.summary,
    };

    if (prisma && isPostgresConnected) {
      try {
        const created = await prisma.benchmarkRun.create({
          data: {
            id: newRun.id,
            taskId: newRun.taskId,
            status: (newRun.status || 'COMPLETED') as any,
            startedAt: new Date(newRun.startedAt),
            completedAt: newRun.completedAt ? new Date(newRun.completedAt) : null,
            scoringWeights: newRun.scoringWeights as any,
            winnerAgentId: newRun.winnerAgentId || null,
            summary: newRun.summary || null,
          },
        });
        memoryStore.benchmarkRuns.unshift(newRun);
        return { ...created, ...newRun };
      } catch (err) {
        console.warn('[Prisma] Fallback to memory store for createRun:', err);
      }
    }

    memoryStore.benchmarkRuns.unshift(newRun);
    return newRun;
  },

  // Leaderboard Aggregation
  async getLeaderboard(category?: string): Promise<any[]> {
    const agents = await this.listAgents();
    return agents
      .map((agent, index) => {
        const isTop = agent.avgScore > 88;
        const isMid = agent.avgScore > 84;
        return {
          rank: index + 1,
          agentId: agent.id,
          agentName: agent.name,
          agentVersion: agent.version,
          overallScore: agent.avgScore || 80.0,
          accuracy: isTop ? 94.2 : isMid ? 88.5 : 82.1,
          avgDurationSec: isTop ? 38.4 : isMid ? 45.2 : 58.7,
          completionRate: isTop ? 96.0 : isMid ? 91.5 : 84.0,
          costEfficiencyScore: isTop ? 88.0 : isMid ? 94.0 : 79.5,
          reliabilityRate: isTop ? 95.0 : isMid ? 92.0 : 86.0,
          totalRuns: agent.totalRuns,
          primaryCategory: category || 'All-Around',
          trend: isTop ? 'up' : 'neutral',
        };
      })
      .sort((a, b) => b.overallScore - a.overallScore);
  },
};

export { prisma };
