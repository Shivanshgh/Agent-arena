import { Router } from 'express';
import { dbService } from '../db/prisma';

export const leaderboardRouter = Router();

// GET /api/leaderboard
leaderboardRouter.get('/', async (req, res, next) => {
  try {
    const { category } = req.query;
    const rankings = await dbService.getLeaderboard(category as string | undefined);
    res.json(rankings);
  } catch (err) {
    next(err);
  }
});
