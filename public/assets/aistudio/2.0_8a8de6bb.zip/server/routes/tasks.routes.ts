import { Router } from 'express';
import { dbService } from '../db/prisma';
import { TaskCreateSchema, TaskUpdateSchema } from '../schemas';
import { AppError } from '../middleware/errorHandler';

export const tasksRouter = Router();

// GET /api/tasks
tasksRouter.get('/', async (req, res, next) => {
  try {
    const { category, difficulty } = req.query;
    const tasks = await dbService.listTasks(
      category as string | undefined,
      difficulty as string | undefined
    );
    res.json(tasks);
  } catch (err) {
    next(err);
  }
});

// GET /api/tasks/:id
tasksRouter.get('/:id', async (req, res, next) => {
  try {
    const task = await dbService.getTaskById(req.params.id);
    if (!task) {
      throw new AppError('Benchmark task not found', 404);
    }
    res.json(task);
  } catch (err) {
    next(err);
  }
});

// POST /api/tasks
tasksRouter.post('/', async (req, res, next) => {
  try {
    const validated = TaskCreateSchema.parse(req.body);
    const created = await dbService.createTask(validated);
    res.status(201).json(created);
  } catch (err) {
    next(err);
  }
});

// DELETE /api/tasks/:id
tasksRouter.delete('/:id', async (req, res, next) => {
  try {
    const deleted = await dbService.deleteTask(req.params.id);
    if (!deleted) {
      throw new AppError('Task not found', 404);
    }
    res.json({ success: true, message: 'Benchmark task deleted' });
  } catch (err) {
    next(err);
  }
});
