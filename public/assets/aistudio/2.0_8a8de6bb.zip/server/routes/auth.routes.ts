import { Router } from 'express';
import { UserRegisterSchema, UserLoginSchema } from '../schemas';
import { AuthenticatedRequest, authenticate } from '../middleware/auth';
import { AppError } from '../middleware/errorHandler';

export const authRouter = Router();

authRouter.post('/register', async (req, res, next) => {
  try {
    const validated = UserRegisterSchema.parse(req.body);
    const user = {
      id: `usr_${Date.now()}`,
      email: validated.email,
      name: validated.name,
      role: validated.role,
      createdAt: new Date().toISOString(),
    };
    res.status(201).json({
      message: 'User registered successfully',
      user,
      token: `dev_token_${user.id}`,
    });
  } catch (err) {
    next(err);
  }
});

authRouter.post('/login', async (req, res, next) => {
  try {
    const validated = UserLoginSchema.parse(req.body);
    res.json({
      message: 'Login successful',
      token: 'dev_token_session_jwt',
      user: {
        id: 'usr_dev_default',
        email: validated.email,
        role: 'DEVELOPER',
      },
    });
  } catch (err) {
    next(err);
  }
});

authRouter.get('/me', authenticate, (req: AuthenticatedRequest, res) => {
  res.json({
    user: req.user,
  });
});
