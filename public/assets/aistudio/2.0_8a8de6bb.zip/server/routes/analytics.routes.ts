import { Router } from 'express';
import { dbService } from '../db/prisma';

export const analyticsRouter = Router();

// GET /api/analytics
analyticsRouter.get('/', async (req, res, next) => {
  try {
    const agents = await dbService.listAgents();
    const runs = await dbService.listRuns();

    const stats = {
      totalAgents: agents.length,
      totalRuns: runs.length,
      avgCompletionRate: 84.6,
      highestScoringAgent: agents.reduce((prev, curr) => (curr.avgScore > prev.avgScore ? curr : prev), agents[0] || {}),
      categorySuccessRates: [
        { category: 'Bug Fixing', devin: 96, aider: 94, swe: 88, openhands: 85, cursor: 82 },
        { category: 'Algorithmic', devin: 92, aider: 86, swe: 84, openhands: 80, cursor: 88 },
        { category: 'Refactoring', devin: 89, aider: 95, swe: 82, openhands: 86, cursor: 81 },
        { category: 'Security', devin: 88, aider: 84, swe: 89, openhands: 78, cursor: 74 },
        { category: 'Database', devin: 91, aider: 87, swe: 85, openhands: 84, cursor: 83 },
      ],
      tokenFootprint: [
        { agent: 'Devin', promptTokens: 3840, completionTokens: 780, total: 4620 },
        { agent: 'Aider', promptTokens: 1890, completionTokens: 410, total: 2300 },
        { agent: 'SWE-Pro', promptTokens: 5420, completionTokens: 960, total: 6380 },
        { agent: 'OpenHands', promptTokens: 4100, completionTokens: 820, total: 4920 },
        { agent: 'Cursor', promptTokens: 2600, completionTokens: 520, total: 3120 },
      ],
      costVsAccuracy: [
        { name: 'Devin-v2.4', cost: 0.024, accuracy: 94.2, duration: 38 },
        { name: 'Aider-Arch', cost: 0.006, accuracy: 91.8, duration: 29 },
        { name: 'SWE-Agent Pro', cost: 0.048, accuracy: 88.5, duration: 52 },
        { name: 'OpenHands', cost: 0.032, accuracy: 85.0, duration: 44 },
        { name: 'Cursor-Runner', cost: 0.015, accuracy: 84.1, duration: 21 },
      ],
    };

    res.json(stats);
  } catch (err) {
    next(err);
  }
});
