import { Router } from 'express';
import { dbService } from '../db/prisma';

export const healthRouter = Router();

healthRouter.get('/', (req, res) => {
  res.json({
    status: 'healthy',
    service: 'AgentArena Backend API',
    version: '1.0.0',
    timestamp: new Date().toISOString(),
    uptimeSeconds: Math.floor(process.uptime()),
  });
});

healthRouter.get('/db', async (req, res, next) => {
  try {
    const health = await dbService.checkDatabaseHealth();
    res.json({
      status: health.connected ? 'healthy' : 'degraded',
      database: health,
      timestamp: new Date().toISOString(),
    });
  } catch (err) {
    next(err);
  }
});
