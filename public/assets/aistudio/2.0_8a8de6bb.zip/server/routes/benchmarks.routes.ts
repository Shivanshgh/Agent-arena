import { Router } from 'express';
import { dbService } from '../db/prisma';
import { AppError } from '../middleware/errorHandler';

export const benchmarksRouter = Router();

// GET /api/benchmarks
benchmarksRouter.get('/', async (req, res, next) => {
  try {
    const runs = await dbService.listRuns();
    res.json(runs);
  } catch (err) {
    next(err);
  }
});

// GET /api/benchmarks/:id
benchmarksRouter.get('/:id', async (req, res, next) => {
  try {
    const run = await dbService.getRunById(req.params.id);
    if (!run) {
      throw new AppError('Benchmark run not found', 404);
    }
    res.json(run);
  } catch (err) {
    next(err);
  }
});

// POST /api/benchmarks (Records benchmark execution)
benchmarksRouter.post('/', async (req, res, next) => {
  try {
    const payload = req.body;
    if (!payload.taskId || !payload.agents || payload.agents.length === 0) {
      throw new AppError('taskId and agents array are required to record a benchmark run', 400);
    }

    const created = await dbService.createRun(payload);
    res.status(201).json(created);
  } catch (err) {
    next(err);
  }
});
