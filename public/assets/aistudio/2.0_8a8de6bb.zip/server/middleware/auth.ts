import { Request, Response, NextFunction } from 'express';
import { AppError } from './errorHandler';

export interface AuthenticatedRequest extends Request {
  user?: {
    id: string;
    email: string;
    role: string;
    name?: string;
  };
}

export const authenticate = (
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
) => {
  const authHeader = req.headers.authorization;
  const apiKey = req.headers['x-api-key'] as string;

  // In Stage 2, support standard developer session or bearer token
  if (apiKey) {
    req.user = {
      id: 'usr_dev_admin',
      email: 'dev@agentarena.internal',
      role: 'ADMIN',
      name: 'AgentArena Developer',
    };
    return next();
  }

  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.split(' ')[1];
    if (token) {
      req.user = {
        id: 'usr_dev_authenticated',
        email: 'engineer@agentarena.internal',
        role: 'DEVELOPER',
        name: 'Benchmark Engineer',
      };
      return next();
    }
  }

  // Allow anonymous access in developer mode with default context
  req.user = {
    id: 'usr_default_dev',
    email: 'developer@agentarena.internal',
    role: 'DEVELOPER',
    name: 'Dev User',
  };
  next();
};

export const requireRole = (allowedRoles: string[]) => {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    if (!req.user || !allowedRoles.includes(req.user.role)) {
      throw new AppError('Forbidden: Insufficient privileges', 403);
    }
    next();
  };
};
