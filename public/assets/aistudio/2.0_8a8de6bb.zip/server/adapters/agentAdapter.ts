import { z } from 'zod';
import {
  ProtocolTaskRequestSchema,
  ProtocolTaskResponseSchema,
  ProtocolHealthResponseSchema,
} from '../schemas';

export type ProtocolTaskRequest = z.infer<typeof ProtocolTaskRequestSchema>;
export type ProtocolTaskResponse = z.infer<typeof ProtocolTaskResponseSchema>;
export type ProtocolHealthResponse = z.infer<typeof ProtocolHealthResponseSchema>;

export interface ConnectionTestResult {
  success: boolean;
  statusCode?: number;
  latencyMs: number;
  message: string;
  protocolVersion?: string;
  agentVersion?: string;
  capabilities?: string[];
  error?: string;
  timestamp: string;
}

export interface StoredAgent {
  id: string;
  name: string;
  version: string;
  endpointUrl: string;
  healthEndpoint?: string;
  integrationType: string;
  authConfig?: {
    type: 'NONE' | 'BEARER_TOKEN' | 'API_KEY' | 'CUSTOM_HEADER';
    token?: string;
    encryptedToken?: string;
    headerName?: string;
  };
  timeoutSeconds?: number;
  capabilities?: string[];
}

export interface AgentAdapter {
  testConnection(agent: StoredAgent): Promise<ConnectionTestResult>;
  executeTask(agent: StoredAgent, request: ProtocolTaskRequest): Promise<ProtocolTaskResponse>;
}
