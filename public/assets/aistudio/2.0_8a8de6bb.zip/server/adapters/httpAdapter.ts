import { AgentAdapter, StoredAgent, ConnectionTestResult, ProtocolTaskRequest, ProtocolTaskResponse } from './agentAdapter';
import { validateEndpointUrl } from '../security/ssrf';
import { decryptSecret } from '../security/crypto';
import { ProtocolTaskResponseSchema } from '../schemas';

export class HttpAgentAdapter implements AgentAdapter {
  private defaultHealthTimeoutMs = 6000;
  private maxResponseSizeBytes = 5 * 1024 * 1024; // 5MB payload limit

  /**
   * Builds headers with decrypted authentication credentials
   */
  private buildHeaders(agent: StoredAgent, customHeaders: Record<string, string> = {}): Record<string, string> {
    const headers: Record<string, string> = {
      'User-Agent': 'AgentArena-Harness/1.0 (+https://agentarena.internal)',
      'Accept': 'application/json',
      'X-Arena-Protocol-Version': '1.0',
      ...customHeaders,
    };

    if (agent.authConfig && agent.authConfig.type !== 'NONE') {
      let rawToken = agent.authConfig.token || '';
      if (!rawToken && agent.authConfig.encryptedToken) {
        rawToken = decryptSecret(agent.authConfig.encryptedToken);
      }

      if (rawToken) {
        switch (agent.authConfig.type) {
          case 'BEARER_TOKEN':
            headers['Authorization'] = `Bearer ${rawToken}`;
            break;
          case 'API_KEY':
            const keyHeader = agent.authConfig.headerName || 'X-API-Key';
            headers[keyHeader] = rawToken;
            break;
          case 'CUSTOM_HEADER':
            const customHeader = agent.authConfig.headerName || 'X-Agent-Secret';
            headers[customHeader] = rawToken;
            break;
        }
      }
    }

    return headers;
  }

  /**
   * Resolves the full URL for the agent's health endpoint
   */
  private resolveHealthUrl(agent: StoredAgent): string {
    const base = agent.endpointUrl.trim();
    const healthPath = (agent.healthEndpoint || '/health').trim();

    try {
      if (healthPath.startsWith('http://') || healthPath.startsWith('https://')) {
        return healthPath;
      }
      const url = new URL(base);
      if (healthPath.startsWith('/')) {
        url.pathname = healthPath;
      } else {
        url.pathname = url.pathname.replace(/\/+$/, '') + '/' + healthPath;
      }
      return url.toString();
    } catch {
      return base.replace(/\/+$/, '') + '/' + healthPath.replace(/^\/+/, '');
    }
  }

  /**
   * Tests connection to an agent's documented health endpoint
   */
  async testConnection(agent: StoredAgent): Promise<ConnectionTestResult> {
    const targetUrl = this.resolveHealthUrl(agent);
    const timestamp = new Date().toISOString();

    // 1. SSRF Pre-flight Validation
    const ssrfCheck = await validateEndpointUrl(targetUrl);
    if (!ssrfCheck.valid) {
      return {
        success: false,
        latencyMs: 0,
        message: `Security validation blocked connection: ${ssrfCheck.error}`,
        error: ssrfCheck.error,
        timestamp,
      };
    }

    const headers = this.buildHeaders(agent);
    const start = performance.now();

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), this.defaultHealthTimeoutMs);

      const response = await fetch(targetUrl, {
        method: 'GET',
        headers,
        signal: controller.signal,
        redirect: 'manual', // Prevent SSRF via redirection to internal IPs
      });

      clearTimeout(timeoutId);
      const latencyMs = Math.round(performance.now() - start);

      if (response.status >= 300 && response.status < 400) {
        return {
          success: false,
          statusCode: response.status,
          latencyMs,
          message: 'Endpoint attempted an HTTP redirect. Redirects are prohibited for security.',
          error: 'REDIRECT_FORBIDDEN',
          timestamp,
        };
      }

      if (!response.ok) {
        return {
          success: false,
          statusCode: response.status,
          latencyMs,
          message: `Agent health endpoint returned HTTP ${response.status} (${response.statusText})`,
          error: `HTTP_${response.status}`,
          timestamp,
        };
      }

      // Parse JSON response
      const json = await response.json().catch(() => null);
      if (!json || typeof json !== 'object') {
        return {
          success: false,
          statusCode: response.status,
          latencyMs,
          message: 'Agent responded with HTTP 200, but response payload was not valid JSON.',
          error: 'INVALID_JSON_RESPONSE',
          timestamp,
        };
      }

      const status = json.status || 'ok';
      const isHealthy = status === 'ok' || status === 'ready' || status === 'healthy' || status === 'READY';

      return {
        success: isHealthy,
        statusCode: response.status,
        latencyMs,
        message: isHealthy
          ? `Connection verified successfully (${latencyMs}ms). Reported status: ${status}.`
          : `Agent reported non-ready status: ${status}`,
        protocolVersion: json.protocolVersion || '1.0',
        agentVersion: json.version || agent.version,
        capabilities: Array.isArray(json.capabilities) ? json.capabilities : agent.capabilities || [],
        timestamp,
      };
    } catch (err: any) {
      const latencyMs = Math.round(performance.now() - start);
      if (err.name === 'AbortError') {
        return {
          success: false,
          latencyMs,
          message: `Connection timed out after ${this.defaultHealthTimeoutMs}ms.`,
          error: 'TIMEOUT',
          timestamp,
        };
      }

      return {
        success: false,
        latencyMs,
        message: `Failed to connect to agent endpoint: ${err.message}`,
        error: err.code || err.message,
        timestamp,
      };
    }
  }

  /**
   * Sends a standardized task request to the agent and parses/validates the response
   */
  async executeTask(agent: StoredAgent, request: ProtocolTaskRequest): Promise<ProtocolTaskResponse> {
    const targetUrl = agent.endpointUrl.trim();
    const start = performance.now();

    // 1. SSRF Pre-flight Validation
    const ssrfCheck = await validateEndpointUrl(targetUrl);
    if (!ssrfCheck.valid) {
      return {
        protocolVersion: '1.0',
        requestId: request.requestId,
        status: 'failed',
        result: null,
        metrics: {
          durationMs: 0,
          inputTokens: null,
          outputTokens: null,
        },
        error: {
          code: 'SSRF_BLOCKED',
          message: `Task execution rejected: ${ssrfCheck.error}`,
        },
        metadata: { blockedUrl: targetUrl },
      };
    }

    const headers = this.buildHeaders(agent, {
      'Content-Type': 'application/json',
      'X-Arena-Request-Id': request.requestId,
    });

    const timeoutSeconds = Math.min(request.constraints.timeoutSeconds || 120, 180);
    const timeoutMs = timeoutSeconds * 1000;

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

      const response = await fetch(targetUrl, {
        method: 'POST',
        headers,
        body: JSON.stringify(request),
        signal: controller.signal,
        redirect: 'manual',
      });

      clearTimeout(timeoutId);
      const durationMs = Math.round(performance.now() - start);

      if (response.status >= 300 && response.status < 400) {
        return {
          protocolVersion: '1.0',
          requestId: request.requestId,
          status: 'failed',
          result: null,
          metrics: { durationMs, inputTokens: null, outputTokens: null },
          error: {
            code: 'REDIRECT_PROHIBITED',
            message: 'Agent returned HTTP redirect, which is prohibited for security.',
          },
          metadata: {},
        };
      }

      if (!response.ok) {
        const errorText = await response.text().catch(() => '');
        return {
          protocolVersion: '1.0',
          requestId: request.requestId,
          status: 'failed',
          result: null,
          metrics: { durationMs, inputTokens: null, outputTokens: null },
          error: {
            code: `HTTP_${response.status}`,
            message: `Agent endpoint returned HTTP ${response.status}: ${errorText.slice(0, 300)}`,
          },
          metadata: { httpStatus: response.status },
        };
      }

      // Check Content-Length if present
      const contentLength = response.headers.get('content-length');
      if (contentLength && parseInt(contentLength, 10) > this.maxResponseSizeBytes) {
        return {
          protocolVersion: '1.0',
          requestId: request.requestId,
          status: 'failed',
          result: null,
          metrics: { durationMs, inputTokens: null, outputTokens: null },
          error: {
            code: 'PAYLOAD_TOO_LARGE',
            message: `Agent response exceeded max allowed size of ${this.maxResponseSizeBytes} bytes.`,
          },
          metadata: {},
        };
      }

      const json = await response.json().catch(() => null);
      if (!json) {
        return {
          protocolVersion: '1.0',
          requestId: request.requestId,
          status: 'failed',
          result: null,
          metrics: { durationMs, inputTokens: null, outputTokens: null },
          error: {
            code: 'MALFORMED_JSON',
            message: 'Agent returned an invalid non-JSON payload.',
          },
          metadata: {},
        };
      }

      // Validate against ProtocolTaskResponseSchema
      const parseResult = ProtocolTaskResponseSchema.safeParse(json);
      if (!parseResult.success) {
        return {
          protocolVersion: '1.0',
          requestId: request.requestId,
          status: 'failed',
          result: null,
          metrics: { durationMs, inputTokens: null, outputTokens: null },
          error: {
            code: 'PROTOCOL_VALIDATION_ERROR',
            message: `Agent response violated Protocol v1.0 schema: ${parseResult.error.issues.map((i) => `${i.path.join('.')}: ${i.message}`).join(', ')}`,
            details: parseResult.error.format(),
          },
          metadata: { rawResponseSample: json },
        };
      }

      return parseResult.data;
    } catch (err: any) {
      const durationMs = Math.round(performance.now() - start);

      if (err.name === 'AbortError') {
        return {
          protocolVersion: '1.0',
          requestId: request.requestId,
          status: 'timed_out',
          result: null,
          metrics: { durationMs, inputTokens: null, outputTokens: null },
          error: {
            code: 'EXECUTION_TIMEOUT',
            message: `Execution timed out after ${timeoutSeconds}s constraint.`,
          },
          metadata: { timeoutSeconds },
        };
      }

      return {
        protocolVersion: '1.0',
        requestId: request.requestId,
        status: 'failed',
        result: null,
        metrics: { durationMs, inputTokens: null, outputTokens: null },
        error: {
          code: 'NETWORK_ERROR',
          message: `Network communication error: ${err.message}`,
        },
        metadata: { errorCode: err.code },
      };
    }
  }
}

export const httpAgentAdapter = new HttpAgentAdapter();
