import { z } from 'zod';

export const UserRegisterSchema = z.object({
  email: z.string().email('Invalid email address format'),
  name: z.string().min(2, 'Name must be at least 2 characters').max(100),
  role: z.enum(['ADMIN', 'DEVELOPER', 'VIEWER']).optional().default('DEVELOPER'),
  password: z.string().min(8, 'Password must be at least 8 characters').optional(),
});

export const UserLoginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1, 'Password is required'),
});

export const AgentAuthConfigSchema = z.object({
  type: z.enum(['NONE', 'BEARER_TOKEN', 'API_KEY', 'CUSTOM_HEADER']).default('NONE'),
  token: z.string().optional(),
  headerName: z.string().optional(),
});

export const AgentCreateSchema = z.object({
  name: z.string().min(2, 'Agent name is required').max(80),
  version: z.string().regex(/^\d+\.\d+(\.\d+)?$/, 'Version must follow semver format (e.g. 1.0.0)').default('1.0.0'),
  description: z.string().min(5, 'Description must be at least 5 characters').max(1000),
  integrationType: z.preprocess(
    (val) => (typeof val === 'string' ? val.toUpperCase() : val),
    z.enum(['HTTP_WEBHOOK', 'DOCKER_CONTAINER', 'BIFROST_GATEWAY'])
  ).default('HTTP_WEBHOOK'),
  endpointUrl: z.string().url('Endpoint URL must be a valid http or https URL'),
  author: z.string().min(1).default('Community Developer'),
  baseModel: z.string().min(1).default('Custom Foundation Model'),
  capabilities: z.array(z.string()).default(['file_edit', 'terminal_exec', 'test_runner']),
  supportedLanguages: z.array(z.string()).default(['python', 'typescript']),
  authConfig: AgentAuthConfigSchema.optional(),
  healthEndpoint: z.string().optional().default('/health'),
  metadata: z.record(z.string(), z.any()).optional(),
});

export const AgentUpdateSchema = AgentCreateSchema.partial();

// Standardized Agent Communication Protocol v1.0 Schemas
export const ProtocolTaskRequestSchema = z.object({
  protocolVersion: z.literal('1.0'),
  requestId: z.string().min(1, 'requestId is required'),
  task: z.object({
    taskId: z.string().min(1),
    title: z.string().min(1),
    description: z.string().min(1),
    language: z.string().min(1),
    starterCode: z.string().optional(),
    input: z.any().optional(),
    testCases: z.array(z.any()).optional(),
  }),
  constraints: z.object({
    timeoutSeconds: z.number().int().min(1).max(600).default(120),
    maxOutputSizeBytes: z.number().int().min(1000).max(10485760).default(100000),
  }),
});

export const ProtocolTaskResponseSchema = z.object({
  protocolVersion: z.literal('1.0'),
  requestId: z.string(),
  status: z.enum(['queued', 'running', 'completed', 'failed', 'timed_out']),
  result: z
    .object({
      content: z.string().optional(),
      diff: z.string().optional(),
      artifacts: z.any().optional(),
    })
    .nullable()
    .optional(),
  metrics: z.object({
    durationMs: z.number(),
    inputTokens: z.number().nullable(),
    outputTokens: z.number().nullable(),
    memoryBytes: z.number().nullable().optional(),
  }),
  error: z
    .object({
      code: z.string().optional(),
      message: z.string(),
      details: z.any().optional(),
    })
    .nullable()
    .optional(),
  metadata: z.record(z.string(), z.any()).optional().default({}),
});

export const ProtocolHealthResponseSchema = z.object({
  status: z.string(),
  version: z.string().optional(),
  protocolVersion: z.string().optional(),
  capabilities: z.array(z.string()).optional(),
});

export const TestCaseSchema = z.object({
  id: z.string(),
  name: z.string().min(1),
  input: z.string(),
  expectedOutput: z.string(),
  isSecret: z.boolean().default(false),
  timeoutMs: z.number().int().min(100).max(30000).default(1000),
});

export const TaskCreateSchema = z.object({
  title: z.string().min(5, 'Title must be at least 5 characters').max(150),
  category: z.preprocess(
    (val) => (typeof val === 'string' ? val.toUpperCase() : val),
    z.enum(['BUG_FIXING', 'ALGORITHMIC', 'SYSTEM_REFACTOR', 'SECURITY', 'DATABASE'])
  ),
  difficulty: z.preprocess(
    (val) => (typeof val === 'string' ? val.toUpperCase() : val),
    z.enum(['EASY', 'MEDIUM', 'HARD', 'SWE_BENCH'])
  ).default('MEDIUM'),
  language: z.string().min(1).default('python'),
  description: z.string().min(10, 'Problem instructions must be at least 10 characters'),
  starterCode: z.string(),
  referenceSolution: z.string().optional(),
  testCases: z.array(TestCaseSchema).min(1, 'At least 1 test case is required'),
  timeLimitSec: z.number().int().min(10).max(600).default(120),
  memoryLimitMb: z.number().int().min(128).max(4096).default(512),
});

export const TaskUpdateSchema = TaskCreateSchema.partial();

export const BenchmarkRunCreateSchema = z.object({
  taskId: z.string().min(1, 'Task ID is required'),
  agentIds: z.array(z.string()).min(1, 'At least one agent must be selected'),
  customTimeLimitSec: z.number().int().min(10).max(600).optional(),
  customMemoryLimitMb: z.number().int().min(128).max(4096).optional(),
  scoringWeights: z.object({
    accuracy: z.number().min(0).max(100),
    taskCompletion: z.number().min(0).max(100),
    reliability: z.number().min(0).max(100),
    speed: z.number().min(0).max(100),
    costEfficiency: z.number().min(0).max(100),
  }).optional(),
});
