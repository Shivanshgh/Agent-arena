import crypto from 'crypto';
import { config } from '../config';

// 256-bit encryption key derived from server secret
const ENCRYPTION_SECRET = process.env.AGENT_SECRET_KEY || config.jwtSecret || 'agentarena-default-secret-salt-32b';
const CIPHER_KEY = crypto.createHash('sha256').update(ENCRYPTION_SECRET).digest();
const ALGORITHM = 'aes-256-gcm';
const IV_LENGTH = 12;

/**
 * Encrypts a sensitive string (e.g. agent API key or token) using AES-256-GCM
 */
export function encryptSecret(plainText: string): string {
  if (!plainText) return '';
  const iv = crypto.randomBytes(IV_LENGTH);
  const cipher = crypto.createCipheriv(ALGORITHM, CIPHER_KEY, iv);
  
  let encrypted = cipher.update(plainText, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  const authTag = cipher.getAuthTag().toString('hex');

  // Format: iv:authTag:encryptedPayload
  return `${iv.toString('hex')}:${authTag}:${encrypted}`;
}

/**
 * Decrypts an encrypted credential string
 */
export function decryptSecret(cipherText: string): string {
  if (!cipherText || !cipherText.includes(':')) return '';
  
  try {
    const parts = cipherText.split(':');
    if (parts.length !== 3) return '';

    const [ivHex, authTagHex, encryptedHex] = parts;
    const iv = Buffer.from(ivHex, 'hex');
    const authTag = Buffer.from(authTagHex, 'hex');
    const decipher = crypto.createDecipheriv(ALGORITHM, CIPHER_KEY, iv);
    decipher.setAuthTag(authTag);

    let decrypted = decipher.update(encryptedHex, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
  } catch (err) {
    console.error('[Crypto] Failed to decrypt agent secret:', err);
    return '';
  }
}

/**
 * Sanitizes an agent record before returning it over the API, ensuring
 * that plaintext secrets and raw encrypted blobs are NEVER exposed to clients.
 */
export function sanitizeAgent<T extends Record<string, any>>(agent: T): T {
  if (!agent) return agent;
  const copy: any = { ...agent };

  if (copy.authConfig) {
    const auth = typeof copy.authConfig === 'string' ? JSON.parse(copy.authConfig) : copy.authConfig;
    copy.authConfig = {
      type: auth.type || 'NONE',
      hasSecret: Boolean(auth.token || auth.encryptedToken),
      headerName: auth.headerName || undefined,
    };
  } else {
    copy.authConfig = {
      type: 'NONE',
      hasSecret: false,
    };
  }

  // Remove any internal or private fields
  delete copy.encryptedToken;
  delete copy.apiKeyHash;

  return copy;
}
