import dns from 'dns';
import net from 'net';
import { config } from '../config';

export interface SSRFValidationResult {
  valid: boolean;
  error?: string;
  resolvedIps?: string[];
  cleanUrl?: string;
}

/**
 * Checks if an IPv4 address falls into reserved or private IP ranges
 */
function isPrivateIPv4(ip: string): boolean {
  const parts = ip.split('.').map(Number);
  if (parts.length !== 4 || parts.some(isNaN)) return true;

  const [a, b, c, d] = parts;

  // 0.0.0.0/8 - Current network
  if (a === 0) return true;

  // 127.0.0.0/8 - Loopback
  if (a === 127) return true;

  // 10.0.0.0/8 - Private Class A
  if (a === 10) return true;

  // 172.16.0.0/12 - Private Class B (172.16.0.0 - 172.31.255.255)
  if (a === 172 && b >= 16 && b <= 31) return true;

  // 192.168.0.0/16 - Private Class C
  if (a === 192 && b === 168) return true;

  // 169.254.0.0/16 - Link-local & Cloud Metadata (AWS, GCP 169.254.169.254)
  if (a === 169 && b === 254) return true;

  // 100.64.0.0/10 - Shared address space / CGNAT (100.64.0.0 - 100.127.255.255)
  if (a === 100 && b >= 64 && b <= 127) return true;

  // 198.18.0.0/15 - Benchmarking
  if (a === 198 && (b === 18 || b === 19)) return true;

  // 224.0.0.0/4 - Multicast (224-239)
  if (a >= 224 && a <= 239) return true;

  // 240.0.0.0/4 - Reserved (240-255)
  if (a >= 240) return true;

  // Broadcast
  if (a === 255 && b === 255 && c === 255 && d === 255) return true;

  return false;
}

/**
 * Checks if an IPv6 address falls into reserved or private IP ranges
 */
function isPrivateIPv6(ip: string): boolean {
  const lower = ip.toLowerCase();

  // ::1 loopback
  if (lower === '::1' || lower === '0:0:0:0:0:0:0:1') return true;

  // :: unspecified
  if (lower === '::' || lower === '0:0:0:0:0:0:0:0') return true;

  // Unique local fc00::/7 (fc00... or fd00...)
  if (lower.startsWith('fc') || lower.startsWith('fd')) return true;

  // Link-local fe80::/10 (fe8, fe9, fea, feb)
  if (lower.startsWith('fe8') || lower.startsWith('fe9') || lower.startsWith('fea') || lower.startsWith('feb')) return true;

  // IPv4-mapped IPv6 (e.g. ::ffff:127.0.0.1 or ::ffff:7f00:1)
  if (lower.startsWith('::ffff:')) {
    const v4Part = lower.replace('::ffff:', '');
    if (net.isIPv4(v4Part)) {
      return isPrivateIPv4(v4Part);
    }
  }

  return false;
}

/**
 * Validates an endpoint URL against SSRF attacks before any outbound request is issued.
 */
export async function validateEndpointUrl(
  rawUrl: string,
  options?: { allowLocal?: boolean }
): Promise<SSRFValidationResult> {
  if (!rawUrl || typeof rawUrl !== 'string') {
    return { valid: false, error: 'Endpoint URL is missing or invalid' };
  }

  let parsed: URL;
  try {
    parsed = new URL(rawUrl.trim());
  } catch {
    return { valid: false, error: 'Malformed URL format' };
  }

  // 1. Protocol Restriction
  const protocol = parsed.protocol.toLowerCase();
  const allowLocal = options?.allowLocal ?? (process.env.ALLOW_LOCAL_AGENTS === 'true' || config.nodeEnv !== 'production');

  if (protocol !== 'http:' && protocol !== 'https:') {
    return {
      valid: false,
      error: `Forbidden protocol "${protocol}". Only HTTP and HTTPS are permitted.`,
    };
  }

  // In production, strictly enforce HTTPS unless allowLocal is explicitly enabled
  if (config.nodeEnv === 'production' && protocol !== 'https:' && !allowLocal) {
    return {
      valid: false,
      error: 'In production environments, agent endpoints must use secure HTTPS.',
    };
  }

  // 2. Reject credentials in URL authority (e.g. http://user:pass@example.com)
  if (parsed.username || parsed.password) {
    return {
      valid: false,
      error: 'URL must not contain embedded user credentials in the host string.',
    };
  }

  // 3. Reject forbidden hostnames
  const hostname = parsed.hostname.toLowerCase();
  if (hostname === 'localhost' || hostname === '127.0.0.1' || hostname === '::1') {
    if (!allowLocal) {
      return {
        valid: false,
        error: 'Loopback and localhost addresses are prohibited for agent endpoints.',
      };
    }
  }

  // 4. DNS Resolution & Rebinding Protection
  // If the host is already an IP address
  if (net.isIP(hostname)) {
    const isPrivate = net.isIPv4(hostname) ? isPrivateIPv4(hostname) : isPrivateIPv6(hostname);
    const isLoopback = hostname === '127.0.0.1' || hostname === '::1' || hostname.startsWith('127.');
    if (isPrivate && !(allowLocal && isLoopback)) {
      return {
        valid: false,
        error: `IP address "${hostname}" belongs to a private, loopback, or cloud-metadata range.`,
      };
    }
    return {
      valid: true,
      resolvedIps: [hostname],
      cleanUrl: parsed.toString(),
    };
  }

  // Resolve hostname via DNS
  try {
    const lookupResults = await dns.promises.lookup(hostname, { all: true });
    if (!lookupResults || lookupResults.length === 0) {
      return { valid: false, error: `Could not resolve hostname "${hostname}"` };
    }

    const resolvedIps = lookupResults.map((r) => r.address);

    for (const res of lookupResults) {
      const isPrivate = res.family === 4 ? isPrivateIPv4(res.address) : isPrivateIPv6(res.address);
      const isLoopback = res.address === '127.0.0.1' || res.address === '::1' || res.address.startsWith('127.');
      if (isPrivate && !(allowLocal && isLoopback)) {
        return {
          valid: false,
          error: `Hostname "${hostname}" resolves to protected or private address ${res.address} (SSRF protection).`,
          resolvedIps,
        };
      }
    }

    return {
      valid: true,
      resolvedIps,
      cleanUrl: parsed.toString(),
    };
  } catch (err: any) {
    return {
      valid: false,
      error: `DNS resolution failed for "${hostname}": ${err.message}`,
    };
  }
}
