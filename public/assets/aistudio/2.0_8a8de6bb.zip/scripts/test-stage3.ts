/**
 * AgentArena Stage 3 Automated Verification Test Suite
 *
 * Verifies:
 * - Agent registration, updates, and deletion
 * - Credential encryption and client-side redaction
 * - SSRF protection (blocking cloud metadata, private IPs, forbidden protocols)
 * - HTTP Adapter connection testing (/health) and standardized task execution (/execute)
 * - Handling of authentication headers, timeouts, and malformed agent responses
 *
 * Includes a dedicated local mock agent server strictly as an automated test fixture.
 */

import http from 'http';
import { validateEndpointUrl } from '../server/security/ssrf';

const BASE_URL = 'http://127.0.0.1:3000/api';
const MOCK_AGENT_PORT = 3099;
const MOCK_AGENT_URL = `http://127.0.0.1:${MOCK_AGENT_PORT}`;

// Enable local test agent loopback in test environment
process.env.ALLOW_LOCAL_AGENTS = 'true';

let mockServer: http.Server;
let lastReceivedAuthHeader: string | undefined;

function startMockAgentServer(): Promise<void> {
  return new Promise((resolve) => {
    mockServer = http.createServer((req, res) => {
      lastReceivedAuthHeader = req.headers['authorization'] as string;

      const url = req.url || '/';

      if (url === '/health' && req.method === 'GET') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(
          JSON.stringify({
            status: 'ok',
            version: '1.2.0',
            protocolVersion: '1.0',
            capabilities: ['file_edit', 'test_runner'],
          })
        );
        return;
      }

      if (url === '/execute' && req.method === 'POST') {
        let body = '';
        req.on('data', (chunk) => (body += chunk));
        req.on('end', () => {
          try {
            const parsed = JSON.parse(body);
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(
              JSON.stringify({
                protocolVersion: '1.0',
                requestId: parsed.requestId || 'req_mock',
                status: 'completed',
                result: {
                  content: 'def solve():\n    return True\n',
                  diff: '--- a/code.py\n+++ b/code.py\n',
                },
                metrics: {
                  durationMs: 420,
                  inputTokens: 150,
                  outputTokens: 60,
                },
                error: null,
                metadata: { mockEngine: 'TestFixtureAgent' },
              })
            );
          } catch {
            res.writeHead(400, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'invalid json' }));
          }
        });
        return;
      }

      if (url === '/malformed') {
        res.writeHead(200, { 'Content-Type': 'text/plain' });
        res.end('<html>Non-JSON Broken Content</html>');
        return;
      }

      if (url === '/bad-protocol') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(
          JSON.stringify({
            protocolVersion: '2.5', // Unsupported protocol version
            status: 'completed',
          })
        );
        return;
      }

      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'not found' }));
    });

    mockServer.listen(MOCK_AGENT_PORT, '127.0.0.1', () => {
      resolve();
    });
  });
}

function stopMockAgentServer(): Promise<void> {
  return new Promise((resolve) => {
    mockServer.close(() => resolve());
  });
}

async function runStage3Tests() {
  console.log('===========================================================');
  console.log('   AgentArena Stage 3: Agent Registration & HTTP Tests');
  console.log('===========================================================\n');

  await startMockAgentServer();

  let passed = 0;
  let total = 0;

  async function test(name: string, fn: () => Promise<boolean>) {
    total++;
    try {
      const ok = await fn();
      if (ok) {
        console.log(`✓ [PASS] ${name}`);
        passed++;
      } else {
        console.error(`✗ [FAIL] ${name}: Assertion failed`);
      }
    } catch (err: any) {
      console.error(`✗ [FAIL] ${name}: ${err.message}`);
    }
  }

  // 1. SSRF Protection: Cloud Metadata URL blocked
  await test('SSRF Guard: Prohibits AWS/GCP Cloud Metadata (169.254.169.254)', async () => {
    const check = await validateEndpointUrl('http://169.254.169.254/latest/meta-data');
    return Boolean(!check.valid && (check.error?.includes('private') || check.error?.includes('cloud-metadata') || check.error?.includes('169.254')));
  });

  // 2. SSRF Protection: Forbidden Schemes (file://, gopher://)
  await test('SSRF Guard: Prohibits non-HTTP protocols (file:///etc/passwd)', async () => {
    const check = await validateEndpointUrl('file:///etc/passwd');
    return Boolean(!check.valid && check.error?.includes('Forbidden protocol'));
  });

  // 3. SSRF Protection: Embedded Authority Credentials
  await test('SSRF Guard: Prohibits embedded authority credentials', async () => {
    const check = await validateEndpointUrl('https://admin:secret@api.example.com');
    return Boolean(!check.valid && check.error?.includes('embedded user credentials'));
  });

  let createdAgentId = '';
  const testSecretToken = 'super-secret-agent-api-key-9988';

  // 4. Agent Registration with Authentication Config
  await test('Agent Registration: POST /api/agents with BEARER_TOKEN config', async () => {
    const res = await fetch(`${BASE_URL}/agents`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'Stage3-Test-Agent',
        version: '1.2.0',
        description: 'Automated test agent fixture for Stage 3 verification',
        integrationType: 'HTTP_WEBHOOK',
        endpointUrl: `${MOCK_AGENT_URL}/execute`,
        healthEndpoint: '/health',
        baseModel: 'Custom Test Harness',
        capabilities: ['file_edit', 'test_runner'],
        supportedLanguages: ['python', 'typescript'],
        authConfig: {
          type: 'BEARER_TOKEN',
          token: testSecretToken,
        },
      }),
    });

    if (!res.ok) {
      const err = await res.text();
      throw new Error(`Status ${res.status}: ${err}`);
    }

    const data = await res.json();
    createdAgentId = data.id;

    return (
      data.id &&
      data.name === 'Stage3-Test-Agent' &&
      data.authConfig?.type === 'BEARER_TOKEN' &&
      data.authConfig?.hasSecret === true
    );
  });

  // 5. Credential Redaction: Token never exposed in GET
  await test('Security: Credential Redaction in GET /api/agents and GET /api/agents/:id', async () => {
    const res = await fetch(`${BASE_URL}/agents/${createdAgentId}`);
    const data = await res.json();

    // Plaintext token must NEVER appear anywhere in the response
    const rawJson = JSON.stringify(data);
    const hasPlaintext = rawJson.includes(testSecretToken);
    const hasEncrypted = rawJson.includes('encryptedToken');

    return !hasPlaintext && !hasEncrypted && data.authConfig?.hasSecret === true;
  });

  // 6. Live Connection Test: POST /api/agents/:id/test against mock agent
  await test('Connection Testing: POST /api/agents/:id/test against mock fixture', async () => {
    const res = await fetch(`${BASE_URL}/agents/${createdAgentId}/test`, {
      method: 'POST',
    });

    const data = await res.json();

    return (
      data.success === true &&
      data.statusCode === 200 &&
      data.protocolVersion === '1.0' &&
      data.latencyMs >= 0 &&
      data.message.includes('verified successfully')
    );
  });

  // 7. Verified Status Updated in DB
  await test('Persistence: Agent status updated to READY and timestamp recorded', async () => {
    const res = await fetch(`${BASE_URL}/agents/${createdAgentId}`);
    const data = await res.json();
    return (data.status?.toUpperCase() === 'READY') && data.lastConnectedAt !== null;
  });

  // 8. Standardized Task Execution: POST /api/agents/:id/execute
  await test('Standardized Protocol: POST /api/agents/:id/execute sends v1.0 payload', async () => {
    const taskPayload = {
      protocolVersion: '1.0',
      requestId: 'req_stage3_verify_001',
      task: {
        taskId: 'task_reverse_string',
        title: 'Reverse string',
        description: 'Reverse string',
        language: 'python',
        starterCode: 'def reverse(): pass',
      },
      constraints: {
        timeoutSeconds: 30,
        maxOutputSizeBytes: 50000,
      },
    };

    const res = await fetch(`${BASE_URL}/agents/${createdAgentId}/execute`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(taskPayload),
    });

    const data = await res.json();

    const isMatch =
      data.protocolVersion === '1.0' &&
      data.requestId === 'req_stage3_verify_001' &&
      data.status === 'completed' &&
      data.result?.content !== undefined &&
      data.metrics?.durationMs > 0 &&
      lastReceivedAuthHeader === `Bearer ${testSecretToken}`;

    return isMatch;
  });

  // 9. Error Handling: Failed Connection on Unreachable Port
  await test('Error Handling: Graceful diagnostics on unreachable endpoint', async () => {
    const res = await fetch(`${BASE_URL}/agents`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'Unreachable-Agent',
        description: 'A test agent for unreachable endpoint verification',
        endpointUrl: 'http://127.0.0.1:49999/execute',
        healthEndpoint: '/health',
      }),
    });
    const badAgent = await res.json();

    const testRes = await fetch(`${BASE_URL}/agents/${badAgent.id}/test`, {
      method: 'POST',
    });
    const testData = await testRes.json();

    // Must return success: false with informative error diagnostic without throwing 500
    const ok = testData.success === false && testData.error !== undefined;

    // Clean up
    await fetch(`${BASE_URL}/agents/${badAgent.id}`, { method: 'DELETE' });
    return ok;
  });

  // 10. Agent Update
  await test('Agent Update: PUT /api/agents/:id updates description & metadata', async () => {
    const res = await fetch(`${BASE_URL}/agents/${createdAgentId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        description: 'Updated description for Stage 3 test agent',
      }),
    });
    const data = await res.json();
    return data.description === 'Updated description for Stage 3 test agent';
  });

  // 11. Agent Deletion
  await test('Agent Deletion: DELETE /api/agents/:id removes agent', async () => {
    const res = await fetch(`${BASE_URL}/agents/${createdAgentId}`, {
      method: 'DELETE',
    });
    const data = await res.json();
    return data.success === true;
  });

  await stopMockAgentServer();

  console.log(`\n===========================================================`);
  console.log(` Stage 3 Test Suite Results: ${passed} of ${total} tests PASSED`);
  console.log(`===========================================================\n`);

  process.exit(passed === total ? 0 : 1);
}

runStage3Tests().catch((err) => {
  console.error('Test run failed unexpectedly:', err);
  if (mockServer) mockServer.close();
  process.exit(1);
});
