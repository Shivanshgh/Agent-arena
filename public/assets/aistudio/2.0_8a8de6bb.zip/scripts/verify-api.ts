/**
 * AgentArena Stage 2 API Verification Test Script
 */

const BASE_URL = 'http://127.0.0.1:3000/api';

async function testEndpoint(name: string, fn: () => Promise<any>) {
  try {
    const res = await fn();
    console.log(`[PASS] ${name}:`, res);
    return true;
  } catch (err: any) {
    console.error(`[FAIL] ${name}:`, err.message);
    return false;
  }
}

async function runVerification() {
  console.log('--- Starting AgentArena Stage 2 API Endpoint Verification ---');
  let passed = 0;
  let total = 0;

  async function check(name: string, url: string, options?: RequestInit, validator?: (data: any) => boolean) {
    total++;
    try {
      const res = await fetch(`${BASE_URL}${url}`, options);
      const json = await res.json();
      if (!res.ok) {
        throw new Error(`HTTP ${res.status}: ${JSON.stringify(json)}`);
      }
      if (validator && !validator(json)) {
        throw new Error(`Validation failed for response: ${JSON.stringify(json)}`);
      }
      console.log(`✓ [PASS] ${options?.method || 'GET'} ${url} (${res.status})`);
      passed++;
      return json;
    } catch (e: any) {
      console.log(`✗ [FAIL] ${options?.method || 'GET'} ${url}: ${e.message}`);
      return null;
    }
  }

  // 1. Health
  await check('Health Check', '/health', undefined, (d) => d.status === 'healthy');

  // 2. DB Health
  await check('DB Health Check', '/health/db', undefined, (d) => d.database !== undefined);

  // 3. Auth Register
  const testUser = {
    email: `test_${Date.now()}@arena.test`,
    password: 'Password123!',
    name: 'Verification Bot',
  };
  const regRes = await check('Auth Register', '/auth/register', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(testUser),
  }, (d) => d.token && d.user);

  // 4. Auth Login
  await check('Auth Login', '/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: testUser.email, password: testUser.password }),
  }, (d) => d.token);

  // 5. Auth Me
  if (regRes?.token) {
    await check('Auth Me', '/auth/me', {
      headers: { Authorization: `Bearer ${regRes.token}` },
    }, (d) => d.user && d.user.email !== undefined);
  }

  // 6. Agents List
  const agents = await check('Agents List', '/agents', undefined, (d) => Array.isArray(d) && d.length > 0);

  // 7. Agent Creation
  const newAgent = await check('Agent Create', '/agents', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      name: 'Stage2-Verify-Agent',
      version: '1.0.0',
      description: 'Automated verification test agent',
      integrationType: 'HTTP_WEBHOOK',
      endpointUrl: 'http://127.0.0.1:3000/api/health',
      healthEndpoint: '/api/health',
      baseModel: 'Gemini 3.8 Flash',
      capabilities: ['file_edit', 'test_runner'],
      supportedLanguages: ['python', 'typescript'],
    }),
  }, (d) => d.id && d.name === 'Stage2-Verify-Agent');

  // 8. Agent Get By ID
  if (newAgent?.id) {
    await check('Agent Get', `/agents/${newAgent.id}`, undefined, (d) => d.id === newAgent.id);

    // 9. Agent Update
    await check('Agent Update', `/agents/${newAgent.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ description: 'Updated verification description' }),
    }, (d) => d.description === 'Updated verification description');

    // 10. Agent Ping
    await check('Agent Ping', `/agents/${newAgent.id}/ping`, {
      method: 'POST',
    }, (d) => d.success === true);

    // 11. Agent Delete
    await check('Agent Delete', `/agents/${newAgent.id}`, {
      method: 'DELETE',
    }, (d) => d.success === true);
  }

  // 12. Tasks List
  const tasks = await check('Tasks List', '/tasks', undefined, (d) => Array.isArray(d) && d.length > 0);

  // 13. Task Create
  const newTask = await check('Task Create', '/tasks', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      title: 'Verify Stage 2 Test Task',
      category: 'BUG_FIXING',
      difficulty: 'MEDIUM',
      language: 'typescript',
      description: 'A task created to verify the Task Manager API endpoints',
      starterCode: 'function verify() { return false; }',
      referenceSolution: 'function verify() { return true; }',
      testCases: [{ id: 'tc_1', name: 'Check truthy', input: 'verify()', expectedOutput: 'true', isSecret: false, timeoutMs: 1000 }],
      timeLimitSec: 60,
      memoryLimitMb: 256,
    }),
  }, (d) => d.id && d.title === 'Verify Stage 2 Test Task');

  // 14. Task Get
  if (newTask?.id) {
    await check('Task Get', `/tasks/${newTask.id}`, undefined, (d) => d.id === newTask.id);

    // 15. Task Delete
    await check('Task Delete', `/tasks/${newTask.id}`, {
      method: 'DELETE',
    }, (d) => d.success === true);
  }

  // 16. Benchmark Runs List
  await check('Benchmark Runs List', '/benchmarks', undefined, (d) => Array.isArray(d));

  // 17. Benchmark Run Create
  const newRun = await check('Benchmark Run Create', '/benchmarks', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      taskId: 'task_rate_limiter_race',
      taskTitle: 'Fix Concurrency Race Condition in Distributed Rate Limiter',
      taskCategory: 'BUG_FIXING',
      agents: ['agent_devin_24', 'agent_swe_pro'],
      status: 'COMPLETED',
      winnerAgentId: 'agent_devin_24',
      summary: 'Automated test benchmark run verification',
      scoringWeights: { accuracy: 40, taskCompletion: 25, reliability: 15, speed: 10, costEfficiency: 10 },
      executions: {
        agent_devin_24: {
          id: 'exec_verify_01',
          agentId: 'agent_devin_24',
          agentName: 'Devin-v2.4',
          agentVersion: '2.4.1',
          status: 'COMPLETED',
          metrics: { durationMs: 38200, inputTokens: 2900, outputTokens: 620, totalTokens: 3520, estimatedCostUsd: 0.018, testsPassed: 4, totalTests: 4, deterministicPassRate: 100 },
          evaluationScore: { overall: 94.1, accuracySubscore: 40, completionSubscore: 25, reliabilitySubscore: 15, speedSubscore: 9.1, costSubscore: 5.0, breakdownExplanation: 'All tests passed' },
        },
      },
    }),
  }, (d) => d.id && d.status === 'COMPLETED');

  // 18. Benchmark Run Get
  if (newRun?.id) {
    await check('Benchmark Run Get', `/benchmarks/${newRun.id}`, undefined, (d) => d.id === newRun.id);
  }

  // 19. Leaderboard
  await check('Leaderboard', '/leaderboard', undefined, (d) => Array.isArray(d) && d.length > 0);

  // 20. Analytics
  await check('Analytics', '/analytics', undefined, (d) => d.totalAgents !== undefined && Array.isArray(d.categorySuccessRates));

  console.log(`\nVerification Complete: ${passed} of ${total} tests passed.`);
  process.exit(passed === total ? 0 : 1);
}

runVerification();
