import React, { useState } from 'react';
import {
  BarChart3,
  TrendingUp,
  Clock,
  Coins,
  Cpu,
  Layers,
  CheckCircle2,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  ZAxis,
  Tooltip,
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  Legend,
  CartesianGrid,
} from 'recharts';
import { Agent, BenchmarkRun } from '../../types';

interface AnalyticsViewProps {
  agents: Agent[];
  runs: BenchmarkRun[];
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({ agents, runs }) => {
  const [selectedMetric, setSelectedMetric] = useState<'accuracy' | 'speed' | 'cost'>('accuracy');

  // Category pass rates data
  const categoryPassRates = [
    { category: 'Bug Fixing', devin: 96, aider: 94, swe: 88, openhands: 85, cursor: 82 },
    { category: 'Algorithmic', devin: 92, aider: 86, swe: 84, openhands: 80, cursor: 88 },
    { category: 'Refactoring', devin: 89, aider: 95, swe: 82, openhands: 86, cursor: 81 },
    { category: 'Security', devin: 88, aider: 84, swe: 89, openhands: 78, cursor: 74 },
    { category: 'Database', devin: 91, aider: 87, swe: 85, openhands: 84, cursor: 83 },
  ];

  // Pareto Frontier: Cost ($) vs Accuracy (%) Scatter data
  const costVsAccuracyData = [
    { name: 'Devin-v2.4', cost: 0.024, accuracy: 94.2, duration: 38 },
    { name: 'Aider-Arch', cost: 0.006, accuracy: 91.8, duration: 29 },
    { name: 'SWE-Agent Pro', cost: 0.048, accuracy: 88.5, duration: 52 },
    { name: 'OpenHands', cost: 0.032, accuracy: 85.0, duration: 44 },
    { name: 'Cursor-Runner', cost: 0.015, accuracy: 84.1, duration: 21 },
  ];

  // Token footprint data (Input tokens vs Output tokens)
  const tokenBreakdownData = [
    { agent: 'Devin', promptTokens: 3840, completionTokens: 780, total: 4620 },
    { agent: 'Aider', promptTokens: 1890, completionTokens: 410, total: 2300 },
    { agent: 'SWE-Pro', promptTokens: 5420, completionTokens: 960, total: 6380 },
    { agent: 'OpenHands', promptTokens: 4100, completionTokens: 820, total: 4920 },
    { agent: 'Cursor', promptTokens: 2600, completionTokens: 520, total: 3120 },
  ];

  // Execution Duration vs Test Passes
  const executionSpeedData = [
    { agent: 'Cursor', durationSec: 21.4, testPassRate: 84 },
    { agent: 'Aider', durationSec: 29.8, testPassRate: 92 },
    { agent: 'Devin', durationSec: 38.4, testPassRate: 94 },
    { agent: 'OpenHands', durationSec: 44.2, testPassRate: 85 },
    { agent: 'SWE-Pro', durationSec: 52.8, testPassRate: 88 },
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-indigo-400" />
            <span>Cross-Agent Benchmark Analytics</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Empirical trade-offs across accuracy, wall-clock latency, token consumption, and dollar inference cost.
          </p>
        </div>
      </div>

      {/* Grid: Accuracy by Category & Cost vs Accuracy Pareto */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Category Pass Rates Bar Chart */}
        <div className="p-5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold text-white">Task Category Success Rates (%)</h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Deterministic test pass rates broken down across programming domains.
              </p>
            </div>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={categoryPassRates} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
                <XAxis dataKey="category" stroke="#64748B" tick={{ fill: '#94A3B8', fontSize: 11 }} />
                <YAxis domain={[60, 100]} stroke="#64748B" tick={{ fill: '#94A3B8', fontSize: 11 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0F172A', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }}
                  itemStyle={{ color: '#E2E8F0' }}
                  formatter={(val: any) => [`${val}%`, '']}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                <Bar name="Devin-v2.4" dataKey="devin" fill="#6366F1" />
                <Bar name="Aider-Arch" dataKey="aider" fill="#10B981" />
                <Bar name="SWE-Agent" dataKey="swe" fill="#F59E0B" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="text-xs text-slate-400 pt-2 border-t border-slate-800 flex items-center justify-between">
            <span>Aider leads in Refactoring; Devin excels in Concurrency & Bug Fixing.</span>
          </div>
        </div>

        {/* Cost vs Accuracy Pareto Analysis */}
        <div className="p-5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold text-white">Cost vs. Accuracy Trade-Off Frontier</h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Dollars per task against deterministic accuracy (Top-left quadrant represents maximum efficiency).
              </p>
            </div>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
                <XAxis
                  type="number"
                  dataKey="cost"
                  name="Cost"
                  unit="$"
                  stroke="#64748B"
                  tick={{ fill: '#94A3B8', fontSize: 11 }}
                />
                <YAxis
                  type="number"
                  dataKey="accuracy"
                  name="Accuracy"
                  unit="%"
                  domain={[80, 100]}
                  stroke="#64748B"
                  tick={{ fill: '#94A3B8', fontSize: 11 }}
                />
                <Tooltip
                  cursor={{ strokeDasharray: '3 3' }}
                  contentStyle={{ backgroundColor: '#0F172A', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }}
                  formatter={(val: any, name: any) => [
                    name === 'Cost' ? `$${Number(val).toFixed(3)}` : `${val}%`,
                    String(name),
                  ]}
                />
                <Scatter name="Agents" data={costVsAccuracyData} fill="#8B5CF6" />
              </ScatterChart>
            </ResponsiveContainer>
          </div>

          <div className="text-xs text-slate-400 pt-2 border-t border-slate-800 flex items-center justify-between">
            <span>Aider achieves 91.8% accuracy at 1/4th the dollar cost of SWE-Agent.</span>
          </div>
        </div>
      </div>

      {/* Grid: Token Footprint & Wall-Clock Duration */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Token Footprint Stacked Bar */}
        <div className="p-5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-4">
          <div>
            <h2 className="text-sm font-semibold text-white">Token Footprint per Benchmark Task</h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Input prompt tokens vs synthesized code output tokens.
            </p>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={tokenBreakdownData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
                <XAxis dataKey="agent" stroke="#64748B" tick={{ fill: '#94A3B8', fontSize: 11 }} />
                <YAxis stroke="#64748B" tick={{ fill: '#94A3B8', fontSize: 11 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0F172A', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }}
                  formatter={(val: any) => [`${Number(val).toLocaleString()} tokens`, '']}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                <Bar name="Prompt Tokens" dataKey="promptTokens" stackId="a" fill="#6366F1" />
                <Bar name="Output Tokens" dataKey="completionTokens" stackId="a" fill="#38BDF8" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="text-xs text-slate-400 pt-2 border-t border-slate-800">
            Compact context strategies (AST pruning, repo indexing) reduce token burn by up to 63%.
          </div>
        </div>

        {/* Wall-Clock Duration Comparison */}
        <div className="p-5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-4">
          <div>
            <h2 className="text-sm font-semibold text-white">Execution Latency (Seconds to Solution)</h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Wall-clock duration from task ingestion to final validated patch.
            </p>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={executionSpeedData} layout="vertical" margin={{ top: 10, right: 20, left: 20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
                <XAxis type="number" stroke="#64748B" tick={{ fill: '#94A3B8', fontSize: 11 }} />
                <YAxis type="category" dataKey="agent" stroke="#64748B" tick={{ fill: '#94A3B8', fontSize: 11 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0F172A', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }}
                  formatter={(val: any) => [`${val}s`, 'Duration']}
                />
                <Bar dataKey="durationSec" fill="#10B981" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="text-xs text-slate-400 pt-2 border-t border-slate-800">
            Cursor-Agent-Runner completes solutions fastest (21.4s) due to localized incremental index cache.
          </div>
        </div>
      </div>
    </div>
  );
};
