import React, { useState } from 'react';
import {
  Bot,
  Plus,
  Radio,
  CheckCircle2,
  XCircle,
  Clock,
  Trash2,
  Edit3,
  ExternalLink,
  Code2,
  Cpu,
  Layers,
  Search,
  AlertCircle,
  Key,
  Send,
  Lock,
  Eye,
  EyeOff,
  Terminal,
} from 'lucide-react';
import {
  Agent,
  AgentIntegrationType,
  AgentAuthConfig,
  ProtocolTaskRequest,
  ProtocolTaskResponse,
  ConnectionTestResult,
} from '../../types';
import { apiClient } from '../../services/apiClient';

interface AgentRegistryProps {
  agents: Agent[];
  onAddAgent: (agent: Agent) => void;
  onUpdateAgent?: (agent: Agent) => void;
  onDeleteAgent: (agentId: string) => void;
  onStartBenchmarkWithAgent?: (agentId: string) => void;
}

export const AgentRegistry: React.FC<AgentRegistryProps> = ({
  agents,
  onAddAgent,
  onUpdateAgent,
  onDeleteAgent,
  onStartBenchmarkWithAgent,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isRegisterModalOpen, setIsRegisterModalOpen] = useState(false);
  const [editingAgent, setEditingAgent] = useState<Agent | null>(null);
  const [testingStatus, setTestingStatus] = useState<
    Record<string, { loading: boolean; result?: string; success?: boolean; error?: string }>
  >({});
  const [showSecretToken, setShowSecretToken] = useState(false);

  // Task Dispatch Inspector Modal State
  const [taskModalAgent, setTaskModalAgent] = useState<Agent | null>(null);
  const [isDispatchingTask, setIsDispatchingTask] = useState(false);
  const [taskDispatchResult, setTaskDispatchResult] = useState<ProtocolTaskResponse | null>(null);
  const [taskDispatchError, setTaskDispatchError] = useState<string | null>(null);

  // New Agent Form State
  const [formData, setFormData] = useState({
    name: '',
    version: '1.0.0',
    description: '',
    integrationType: 'http_webhook' as AgentIntegrationType,
    endpointUrl: 'https://',
    healthEndpoint: '/health',
    author: '',
    baseModel: '',
    capabilities: ['file_edit', 'terminal_exec', 'test_runner'],
    supportedLanguages: ['python', 'typescript'],
    authType: 'NONE' as AgentAuthConfig['type'],
    authToken: '',
    authHeaderName: '',
  });

  const availableCapabilities = [
    { id: 'file_edit', label: 'File Editing' },
    { id: 'terminal_exec', label: 'Terminal / Shell Execution' },
    { id: 'git_branching', label: 'Git Branching & PRs' },
    { id: 'test_runner', label: 'Autonomous Test Runner' },
    { id: 'multi_file_reasoning', label: 'Multi-File AST Reasoning' },
    { id: 'docker_sandbox', label: 'Isolated Container Sandbox' },
  ];

  const availableLanguages = ['python', 'typescript', 'go', 'rust', 'c++', 'java'];

  const handleTestConnection = async (agent: Agent) => {
    setTestingStatus((prev) => ({
      ...prev,
      [agent.id]: { loading: true },
    }));

    try {
      const result: ConnectionTestResult = await apiClient.agents.testConnection(agent.id);

      setTestingStatus((prev) => ({
        ...prev,
        [agent.id]: {
          loading: false,
          success: result.success,
          result: `${result.message} (${result.latencyMs}ms)`,
          error: result.error,
        },
      }));

      // Update agent state locally if test changed connection status
      if (onUpdateAgent) {
        onUpdateAgent({
          ...agent,
          status: result.success ? 'ready' : 'error',
          lastConnectedAt: result.timestamp,
        });
      }
    } catch (err: any) {
      setTestingStatus((prev) => ({
        ...prev,
        [agent.id]: {
          loading: false,
          success: false,
          result: `Connection failed: ${err.message}`,
          error: err.message,
        },
      }));
    }
  };

  const handleDispatchSampleTask = async () => {
    if (!taskModalAgent) return;
    setIsDispatchingTask(true);
    setTaskDispatchResult(null);
    setTaskDispatchError(null);

    const sampleRequest: ProtocolTaskRequest = {
      protocolVersion: '1.0',
      requestId: `req_test_${Date.now()}`,
      task: {
        taskId: 'task_sample_reverse',
        title: 'Reverse Words in String with Delimiters',
        description: 'Given a string of words separated by spaces, reverse the sequence of words preserving spacing.',
        language: 'python',
        starterCode: 'def reverse_words(s: str) -> str:\n    pass\n',
        input: { s: 'hello autonomous agent' },
      },
      constraints: {
        timeoutSeconds: 30,
        maxOutputSizeBytes: 100000,
      },
    };

    try {
      const response = await apiClient.agents.executeTask(taskModalAgent.id, sampleRequest);
      setTaskDispatchResult(response);
    } catch (err: any) {
      setTaskDispatchError(err.message || 'Execution failed');
    } finally {
      setIsDispatchingTask(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.endpointUrl.trim()) return;

    const authConfig: AgentAuthConfig = {
      type: formData.authType,
      token: formData.authToken.trim() || undefined,
      headerName: formData.authHeaderName.trim() || undefined,
    };

    const newAgent: Agent = {
      id: `agent_${Date.now()}`,
      name: formData.name.trim(),
      version: formData.version.trim() || '1.0.0',
      description: formData.description.trim() || 'Custom registered autonomous agent.',
      integrationType: formData.integrationType,
      endpointUrl: formData.endpointUrl.trim(),
      healthEndpoint: formData.healthEndpoint.trim() || '/health',
      author: formData.author.trim() || 'Local Developer',
      createdAt: new Date().toISOString(),
      status: 'ready',
      capabilities: formData.capabilities,
      supportedLanguages: formData.supportedLanguages,
      baseModel: formData.baseModel.trim() || 'Custom LLM',
      avgScore: 0,
      totalRuns: 0,
      lastActive: 'Just registered',
      authConfig,
    };

    onAddAgent(newAgent);
    setIsRegisterModalOpen(false);
    setFormData({
      name: '',
      version: '1.0.0',
      description: '',
      integrationType: 'http_webhook',
      endpointUrl: 'https://',
      healthEndpoint: '/health',
      author: '',
      baseModel: '',
      capabilities: ['file_edit', 'terminal_exec', 'test_runner'],
      supportedLanguages: ['python', 'typescript'],
      authType: 'NONE',
      authToken: '',
      authHeaderName: '',
    });
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAgent) return;
    if (onUpdateAgent) {
      onUpdateAgent(editingAgent);
    }
    setEditingAgent(null);
  };

  const filteredAgents = agents.filter(
    (a) =>
      a.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.baseModel.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
              <Bot className="w-5 h-5 text-indigo-400" />
              <span>Agent Registry</span>
            </h1>
            <span className="px-2 py-0.5 rounded bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 font-mono text-[10px] font-semibold uppercase">
              Stage 3 Protocol v1.0 Active
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Register, configure authentication, verify endpoints via SSRF-safe health checks, and dispatch standardized HTTP tasks.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search registered agents..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-8 pr-3 py-1.5 text-xs rounded-lg bg-slate-900 border border-slate-800 text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 w-56"
            />
          </div>

          <button
            onClick={() => setIsRegisterModalOpen(true)}
            className="px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white text-xs font-semibold shadow-sm shadow-indigo-600/30 flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            <span>Register Agent</span>
          </button>
        </div>
      </div>

      {/* Protocol Banner */}
      <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs text-slate-400">
        <div className="flex items-center gap-3">
          <Layers className="w-4 h-4 text-violet-400 shrink-0" />
          <span>
            <strong className="text-slate-200">Standardized Communication Contract:</strong> Connected agents implement{' '}
            <code className="text-indigo-300 font-mono">GET /health</code> and <code className="text-indigo-300 font-mono">POST /execute</code> (Protocol v1.0). Secret credentials remain securely encrypted server-side with AES-256-GCM.
          </span>
        </div>
        <div className="flex items-center gap-2 shrink-0 text-[11px] font-mono">
          <span className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-300">SSRF Guard: Enforced</span>
          <span className="px-2 py-0.5 rounded bg-indigo-950 border border-indigo-700 text-indigo-300">Protocol: v1.0</span>
        </div>
      </div>

      {/* Agent Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredAgents.map((agent) => {
          const testStatus = testingStatus[agent.id];
          const isHealthy = agent.status === 'ready' || agent.status === 'busy';

          return (
            <div
              key={agent.id}
              className="p-5 rounded-xl bg-slate-900/70 border border-slate-800 flex flex-col justify-between hover:border-slate-700 transition-colors shadow-sm"
            >
              <div>
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-lg bg-indigo-950/80 border border-indigo-500/30 flex items-center justify-center text-indigo-400 font-bold font-mono text-xs">
                      {agent.name.slice(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white tracking-tight flex items-center gap-2">
                        <span>{agent.name}</span>
                        <span className="text-[10px] text-slate-400 font-mono font-normal">v{agent.version}</span>
                      </h3>
                      <div className="text-[11px] text-slate-400 font-mono flex items-center gap-2">
                        <span>by {agent.author}</span>
                        {agent.authConfig?.hasSecret && (
                          <span className="flex items-center gap-1 text-[10px] text-emerald-400">
                            <Lock className="w-2.5 h-2.5" />
                            <span>Auth Protected</span>
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => setEditingAgent({ ...agent })}
                      title="Edit agent settings"
                      className="text-slate-500 hover:text-slate-200 transition-colors p-1"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => {
                        if (window.confirm(`Are you sure you want to delete ${agent.name} from the registry?`)) {
                          onDeleteAgent(agent.id);
                        }
                      }}
                      title="Remove agent from registry"
                      className="text-slate-500 hover:text-rose-400 transition-colors p-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <p className="text-xs text-slate-300 mt-2 line-clamp-3 leading-relaxed">
                  {agent.description}
                </p>

                {/* Technical Specifications */}
                <div className="mt-4 space-y-2 pt-3 border-t border-slate-800/80 text-[11px]">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Base Model:</span>
                    <span className="font-mono text-slate-300 truncate max-w-[170px]">{agent.baseModel}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Connection Status:</span>
                    <span className="flex items-center gap-1.5 font-mono text-[10px]">
                      <span
                        className={`w-1.5 h-1.5 rounded-full ${
                          isHealthy ? 'bg-emerald-400 animate-pulse' : 'bg-rose-400'
                        }`}
                      />
                      <span className={isHealthy ? 'text-emerald-300 font-semibold uppercase' : 'text-rose-300 uppercase'}>
                        {agent.status}
                      </span>
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Benchmark Avg:</span>
                    <span className="font-mono font-bold text-emerald-400 tabular-nums">
                      {agent.avgScore > 0 ? `${agent.avgScore} pts` : 'No runs yet'}
                    </span>
                  </div>
                  {agent.lastConnectedAt && (
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">Last Verified:</span>
                      <span className="font-mono text-[10px] text-slate-400">
                        {new Date(agent.lastConnectedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                      </span>
                    </div>
                  )}
                </div>

                {/* Capabilities Badges */}
                <div className="mt-3 flex flex-wrap gap-1">
                  {agent.capabilities.slice(0, 3).map((cap) => (
                    <span
                      key={cap}
                      className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 text-[10px] font-mono"
                    >
                      {cap.replace('_', ' ')}
                    </span>
                  ))}
                  {agent.capabilities.length > 3 && (
                    <span className="text-[10px] text-slate-500 font-mono self-center">
                      +{agent.capabilities.length - 3} more
                    </span>
                  )}
                </div>

                {/* Endpoint preview */}
                <div className="mt-3 px-2 py-1.5 rounded bg-slate-950 border border-slate-800/80 font-mono text-[10px] text-slate-400 truncate flex items-center justify-between">
                  <span className="truncate">{agent.endpointUrl}</span>
                  <Radio className={`w-2.5 h-2.5 shrink-0 ml-1.5 ${isHealthy ? 'text-emerald-400' : 'text-slate-600'}`} />
                </div>

                {/* Connection Ping Status Result */}
                {testStatus?.result && (
                  <div
                    className={`mt-2 p-2 rounded text-[11px] font-mono ${
                      testStatus.success
                        ? 'bg-emerald-950/40 border border-emerald-800/50 text-emerald-300'
                        : 'bg-rose-950/40 border border-rose-800/50 text-rose-300'
                    }`}
                  >
                    {testStatus.result}
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="mt-5 pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2">
                <button
                  onClick={() => handleTestConnection(agent)}
                  disabled={testStatus?.loading}
                  className="px-2.5 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                  title="Verify health endpoint and measure network roundtrip"
                >
                  <Radio className="w-3 h-3 text-indigo-400" />
                  <span>{testStatus?.loading ? 'Connecting...' : 'Test Connection'}</span>
                </button>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => {
                      setTaskModalAgent(agent);
                      setTaskDispatchResult(null);
                      setTaskDispatchError(null);
                    }}
                    className="px-2 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-indigo-300 text-xs font-medium transition-colors flex items-center gap-1 cursor-pointer"
                    title="Dispatch a standardized test task to verify protocol exchange"
                  >
                    <Send className="w-3 h-3" />
                    <span>Test Task</span>
                  </button>

                  {onStartBenchmarkWithAgent && (
                    <button
                      onClick={() => onStartBenchmarkWithAgent(agent.id)}
                      className="px-2.5 py-1.5 rounded bg-indigo-600/20 hover:bg-indigo-600 text-indigo-300 hover:text-white text-xs font-medium transition-colors cursor-pointer"
                    >
                      Arena
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Task Dispatch Inspector Modal */}
      {taskModalAgent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-2xl rounded-xl bg-slate-900 border border-slate-800 p-6 space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h2 className="text-base font-bold text-white flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-indigo-400" />
                  <span>Dispatch Standardized Task — {taskModalAgent.name}</span>
                </h2>
                <p className="text-xs text-slate-400 mt-0.5 font-mono">
                  Target: {taskModalAgent.endpointUrl} (Protocol v1.0 Contract)
                </p>
              </div>
              <button onClick={() => setTaskModalAgent(null)} className="text-slate-500 hover:text-white p-1">
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
                <div className="text-slate-400 font-semibold mb-1 flex items-center justify-between">
                  <span>OUTGOING PROTOCOL PAYLOAD</span>
                  <span className="font-mono text-[10px] text-indigo-400">POST /execute</span>
                </div>
                <pre className="text-[11px] font-mono text-slate-300 overflow-x-auto p-2 bg-slate-900/60 rounded">
{JSON.stringify(
  {
    protocolVersion: '1.0',
    requestId: 'req_test_live_sample',
    task: {
      taskId: 'task_sample_reverse',
      title: 'Reverse Words in String with Delimiters',
      language: 'python',
      starterCode: 'def reverse_words(s: str) -> str:\n    pass\n',
    },
    constraints: {
      timeoutSeconds: 30,
      maxOutputSizeBytes: 100000,
    },
  },
  null,
  2
)}
                </pre>
              </div>

              {taskDispatchError && (
                <div className="p-3 rounded-lg bg-rose-950/40 border border-rose-800/60 text-rose-300 flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold">Execution Failed</div>
                    <div className="text-[11px] mt-0.5">{taskDispatchError}</div>
                  </div>
                </div>
              )}

              {taskDispatchResult && (
                <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 space-y-2">
                  <div className="text-emerald-400 font-semibold flex items-center justify-between">
                    <span className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>AGENT PROTOCOL RESPONSE (Status: {taskDispatchResult.status})</span>
                    </span>
                    <span className="font-mono text-[10px] text-slate-400">
                      Duration: {taskDispatchResult.metrics.durationMs}ms
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-[11px] font-mono text-slate-300">
                    <div className="p-2 rounded bg-slate-900">
                      <span className="text-slate-500 block text-[10px]">Status:</span>
                      <span className="font-semibold text-white">{taskDispatchResult.status}</span>
                    </div>
                    <div className="p-2 rounded bg-slate-900">
                      <span className="text-slate-500 block text-[10px]">Duration:</span>
                      <span>{taskDispatchResult.metrics.durationMs}ms</span>
                    </div>
                    <div className="p-2 rounded bg-slate-900">
                      <span className="text-slate-500 block text-[10px]">Tokens:</span>
                      <span>
                        {taskDispatchResult.metrics.inputTokens ?? 'null'} in / {taskDispatchResult.metrics.outputTokens ?? 'null'} out
                      </span>
                    </div>
                  </div>

                  {taskDispatchResult.result?.content && (
                    <div className="mt-2">
                      <span className="text-slate-400 font-mono text-[10px] block mb-1">Generated Output / Diff:</span>
                      <pre className="text-[11px] font-mono text-slate-200 overflow-x-auto p-2.5 bg-slate-900 rounded max-h-40 overflow-y-auto">
                        {taskDispatchResult.result.content}
                      </pre>
                    </div>
                  )}

                  {taskDispatchResult.error && (
                    <div className="p-2 rounded bg-rose-950/40 border border-rose-800 text-rose-300 text-[11px] font-mono">
                      Error: {taskDispatchResult.error.message}
                    </div>
                  )}
                </div>
              )}

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setTaskModalAgent(null)}
                  className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300"
                >
                  Close
                </button>
                <button
                  type="button"
                  onClick={handleDispatchSampleTask}
                  disabled={isDispatchingTask}
                  className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold flex items-center gap-1.5 disabled:opacity-50 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isDispatchingTask ? 'Dispatching...' : 'Dispatch Request'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit Agent Modal */}
      {editingAgent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-lg rounded-xl bg-slate-900 border border-slate-800 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h2 className="text-base font-bold text-white">Edit Agent Configuration</h2>
              <button onClick={() => setEditingAgent(null)} className="text-slate-500 hover:text-white p-1">
                <XCircle className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleEditSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Agent Name</label>
                <input
                  type="text"
                  required
                  value={editingAgent.name}
                  onChange={(e) => setEditingAgent({ ...editingAgent, name: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 focus:outline-none"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Version Tag</label>
                  <input
                    type="text"
                    value={editingAgent.version}
                    onChange={(e) => setEditingAgent({ ...editingAgent, version: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Base Model</label>
                  <input
                    type="text"
                    value={editingAgent.baseModel}
                    onChange={(e) => setEditingAgent({ ...editingAgent, baseModel: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 focus:outline-none"
                  />
                </div>
              </div>
              <div>
                <label className="block text-slate-300 font-medium mb-1">Endpoint URL</label>
                <input
                  type="url"
                  required
                  value={editingAgent.endpointUrl}
                  onChange={(e) => setEditingAgent({ ...editingAgent, endpointUrl: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 font-mono text-[11px] focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-slate-300 font-medium mb-1">Description</label>
                <textarea
                  rows={2}
                  value={editingAgent.description}
                  onChange={(e) => setEditingAgent({ ...editingAgent, description: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 focus:outline-none"
                />
              </div>
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setEditingAgent(null)}
                  className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold cursor-pointer"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Register Agent Modal */}
      {isRegisterModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-xl rounded-xl bg-slate-900 border border-slate-800 p-6 space-y-5 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h2 className="text-base font-bold text-white">Register Autonomous Coding Agent</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Connect an external agent endpoint to the AgentArena execution engine (Protocol v1.0).
                </p>
              </div>
              <button
                onClick={() => setIsRegisterModalOpen(false)}
                className="text-slate-500 hover:text-white p-1"
              >
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Agent Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. MyCoderAgent"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Version</label>
                  <input
                    type="text"
                    placeholder="e.g. 1.0.0"
                    value={formData.version}
                    onChange={(e) => setFormData({ ...formData, version: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Description</label>
                <textarea
                  rows={2}
                  placeholder="Architecture summary, core agent capabilities, and toolchain..."
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Integration Type</label>
                  <select
                    value={formData.integrationType}
                    onChange={(e) => setFormData({ ...formData, integrationType: e.target.value as AgentIntegrationType })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="http_webhook">HTTP Webhook (Standard v1.0)</option>
                    <option value="docker_container">Docker Container Image</option>
                    <option value="bifrost_gateway">Bifrost Gateway</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Base Model / Engine</label>
                  <input
                    type="text"
                    placeholder="e.g. Claude 3.7 Sonnet / Gemini 3.8"
                    value={formData.baseModel}
                    onChange={(e) => setFormData({ ...formData, baseModel: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-2">
                  <label className="block text-slate-300 font-medium mb-1">API Endpoint URL *</label>
                  <input
                    type="url"
                    required
                    placeholder="https://my-agent.internal.net/api/v1/execute"
                    value={formData.endpointUrl}
                    onChange={(e) => setFormData({ ...formData, endpointUrl: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 font-mono text-[11px] focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Health Path</label>
                  <input
                    type="text"
                    placeholder="/health"
                    value={formData.healthEndpoint}
                    onChange={(e) => setFormData({ ...formData, healthEndpoint: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 font-mono text-[11px] focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              {/* Authentication Configuration (Security Hardened) */}
              <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800/80 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-slate-300 font-semibold flex items-center gap-1.5">
                    <Key className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Agent Authentication Configuration</span>
                  </label>
                  <span className="text-[10px] text-slate-400 font-mono">AES-256-GCM Encrypted</span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-400 mb-1">Auth Scheme</label>
                    <select
                      value={formData.authType}
                      onChange={(e) => setFormData({ ...formData, authType: e.target.value as any })}
                      className="w-full px-3 py-1.5 rounded bg-slate-900 border border-slate-700 text-slate-200"
                    >
                      <option value="NONE">None (Public / Open)</option>
                      <option value="BEARER_TOKEN">Bearer Token (Authorization: Bearer ...)</option>
                      <option value="API_KEY">API Key Header (X-API-Key: ...)</option>
                      <option value="CUSTOM_HEADER">Custom Header</option>
                    </select>
                  </div>

                  {formData.authType !== 'NONE' && (
                    <div>
                      <label className="block text-slate-400 mb-1">
                        {formData.authType === 'CUSTOM_HEADER' ? 'Header Name *' : 'Custom Header (Optional)'}
                      </label>
                      <input
                        type="text"
                        placeholder={formData.authType === 'API_KEY' ? 'X-API-Key' : 'X-Custom-Secret'}
                        value={formData.authHeaderName}
                        onChange={(e) => setFormData({ ...formData, authHeaderName: e.target.value })}
                        className="w-full px-3 py-1.5 rounded bg-slate-900 border border-slate-700 text-slate-200 font-mono text-[11px]"
                      />
                    </div>
                  )}
                </div>

                {formData.authType !== 'NONE' && (
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-slate-400">Secret Token / Key</label>
                      <button
                        type="button"
                        onClick={() => setShowSecretToken(!showSecretToken)}
                        className="text-slate-400 hover:text-slate-200 flex items-center gap-1 text-[10px]"
                      >
                        {showSecretToken ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                        <span>{showSecretToken ? 'Hide' : 'Show'}</span>
                      </button>
                    </div>
                    <input
                      type={showSecretToken ? 'text' : 'password'}
                      placeholder="Enter agent authentication token or secret key..."
                      value={formData.authToken}
                      onChange={(e) => setFormData({ ...formData, authToken: e.target.value })}
                      className="w-full px-3 py-1.5 rounded bg-slate-900 border border-slate-700 text-slate-200 font-mono text-[11px]"
                    />
                  </div>
                )}
              </div>

              {/* Capabilities checklist */}
              <div>
                <label className="block text-slate-300 font-medium mb-1.5">Supported Capabilities</label>
                <div className="grid grid-cols-2 gap-2">
                  {availableCapabilities.map((cap) => {
                    const isChecked = formData.capabilities.includes(cap.id);
                    return (
                      <label
                        key={cap.id}
                        className={`p-2 rounded border flex items-center gap-2 cursor-pointer transition-colors ${
                          isChecked
                            ? 'bg-indigo-950/40 border-indigo-500/50 text-indigo-200'
                            : 'bg-slate-950 border-slate-800 text-slate-400'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setFormData({ ...formData, capabilities: [...formData.capabilities, cap.id] });
                            } else {
                              setFormData({ ...formData, capabilities: formData.capabilities.filter((c) => c !== cap.id) });
                            }
                          }}
                          className="rounded border-slate-700 text-indigo-600 focus:ring-0"
                        />
                        <span className="text-[11px]">{cap.label}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsRegisterModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white font-semibold shadow-md shadow-indigo-600/30 cursor-pointer"
                >
                  Complete Registration
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
