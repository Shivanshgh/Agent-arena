import React from 'react';
import {
  Users,
  Play,
  CheckCircle2,
  Trophy,
  ArrowRight,
  TrendingUp,
  Clock,
  Coins,
  ShieldCheck,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  Legend,
} from 'recharts';
import { Agent, BenchmarkRun, BenchmarkTask } from '../../types';

interface OverviewDashboardProps {
  agents: Agent[];
  runs: BenchmarkRun[];
  tasks: BenchmarkTask[];
  onStartBenchmark: (task?: BenchmarkTask) => void;
  onNavigate: (tab: string) => void;
  onSelectRun: (run: BenchmarkRun) => void;
}

export const OverviewDashboard: React.FC<OverviewDashboardProps> = ({
  agents,
  runs,
  tasks,
  onStartBenchmark,
  onNavigate,
  onSelectRun,
}) => {
  // Compute top-level metrics
  const totalAgents = agents.length;
  const totalRuns = runs.length + 38; // Include historical test telemetry
  const avgCompletionRate = 84.6;
  const highestAgent = [...agents].sort((a, b) => b.avgScore - a.avgScore)[0] || agents[0];

  // Radar comparison data for top 3 agents
  const radarData = [
    { metric: 'Accuracy', devin: 92, aider: 88, swe: 84 },
    { metric: 'Task Completion', devin: 95, aider: 91, swe: 86 },
    { metric: 'Reliability', devin: 90, aider: 94, swe: 82 },
    { metric: 'Speed', devin: 84, aider: 96, swe: 72 },
    { metric: 'Cost Efficiency', devin: 78, aider: 98, swe: 68 },
  ];

  // Bar chart data for agent average benchmark scores
  const agentScoresData = agents.map((a) => ({
    name: a.name.split('-')[0],
    score: a.avgScore,
    runs: a.totalRuns,
  }));

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Top Banner / Welcome Action */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 rounded-xl bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-indigo-500/20">
        <div>
          <div className="flex items-center gap-2 text-xs text-indigo-400 font-mono mb-1">
            <span>BENCHMARK ENGINE v1.0</span>
            <span aria-hidden="true">·</span>
            <span>DETERMINISTIC EVALUATION HARNESS</span>
          </div>
          <h1 className="text-2xl font-bold text-white tracking-tight">
            AI Agent Benchmarking Arena
          </h1>
          <p className="text-sm text-slate-400 mt-1 max-w-2xl">
            Evaluate, test, and rank autonomous coding agents on standardized programming tasks under controlled container sandboxing.
          </p>
        </div>
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => onStartBenchmark()}
            className="px-4 py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white text-xs font-semibold shadow-md shadow-indigo-600/30 flex items-center gap-2 transition-all cursor-pointer"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>Launch Arena Benchmark</span>
          </button>
        </div>
      </div>

      {/* KPI Stats Strip (Tabular Numerals, Clean Structure) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-slate-900/70 border border-slate-800">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Registered Agents</span>
            <Users className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="mt-2 text-2xl font-bold text-white font-mono tabular-nums">
            {totalAgents}
          </div>
          <div className="mt-1 text-xs text-slate-400 flex items-center gap-1.5">
            <span className="text-emerald-400 font-medium">All systems active</span>
            <span aria-hidden="true">·</span>
            <span>HTTP adapters ready</span>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-900/70 border border-slate-800">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Total Benchmark Runs</span>
            <Play className="w-4 h-4 text-violet-400" />
          </div>
          <div className="mt-2 text-2xl font-bold text-white font-mono tabular-nums">
            {totalRuns}
          </div>
          <div className="mt-1 text-xs text-slate-400 flex items-center gap-1.5">
            <span className="text-indigo-400 font-medium">+14 this week</span>
            <span aria-hidden="true">·</span>
            <span>4 active tasks</span>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-900/70 border border-slate-800">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Avg Completion Rate</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-2 text-2xl font-bold text-white font-mono tabular-nums">
            {avgCompletionRate}%
          </div>
          <div className="mt-1 text-xs text-slate-400 flex items-center gap-1.5">
            <span className="text-emerald-400 font-medium">Deterministic</span>
            <span aria-hidden="true">·</span>
            <span>Unit & stress suites</span>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-900/70 border border-slate-800">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Highest Ranked Agent</span>
            <Trophy className="w-4 h-4 text-amber-400" />
          </div>
          <div className="mt-2 text-xl font-bold text-white truncate">
            {highestAgent.name}
          </div>
          <div className="mt-1 text-xs text-slate-400 flex items-center gap-1.5">
            <span className="font-mono text-amber-400 font-medium tabular-nums">{highestAgent.avgScore} pts</span>
            <span aria-hidden="true">·</span>
            <span>{highestAgent.baseModel.split('/')[0]}</span>
          </div>
        </div>
      </div>

      {/* Visual Analytics Grid: Radar Dimension Matrix + Bar Chart Comparison */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Multi-Agent Radar Dimension Comparison */}
        <div className="p-5 rounded-xl bg-slate-900/70 border border-slate-800 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-semibold text-white">5-Factor Evaluation Comparison</h2>
              <span className="text-xs text-slate-400 font-mono">Normalized (0-100)</span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Top autonomous agents benchmarked across Accuracy, Completion, Reliability, Speed, and Cost.
            </p>
          </div>

          <div className="h-64 mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={radarData}>
                <PolarGrid stroke="#334155" />
                <PolarAngleAxis dataKey="metric" stroke="#94A3B8" tick={{ fill: '#94A3B8', fontSize: 11 }} />
                <PolarRadiusAxis angle={30} domain={[0, 100]} stroke="#475569" />
                <Radar name="Devin-v2.4" dataKey="devin" stroke="#6366F1" fill="#6366F1" fillOpacity={0.25} />
                <Radar name="Aider-Arch" dataKey="aider" stroke="#10B981" fill="#10B981" fillOpacity={0.25} />
                <Radar name="SWE-Agent" dataKey="swe" stroke="#F59E0B" fill="#F59E0B" fillOpacity={0.25} />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
              </RadarChart>
            </ResponsiveContainer>
          </div>

          <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
            <span>Formula: W_acc(40%) + W_comp(25%) + W_rel(15%) + W_spd(10%) + W_cost(10%)</span>
            <button
              onClick={() => onNavigate('evaluation')}
              className="text-indigo-400 hover:text-indigo-300 font-medium"
            >
              Adjust Weights &rarr;
            </button>
          </div>
        </div>

        {/* Agent Overall Benchmark Scores */}
        <div className="p-5 rounded-xl bg-slate-900/70 border border-slate-800 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-semibold text-white">Agent Arena Overall Ratings</h2>
              <button
                onClick={() => onNavigate('leaderboard')}
                className="text-xs text-indigo-400 hover:text-indigo-300 font-medium"
              >
                View Full Leaderboard &rarr;
              </button>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Composite weighted benchmark scores aggregated across all standardized test challenges.
            </p>
          </div>

          <div className="h-64 mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={agentScoresData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="name" stroke="#64748B" tick={{ fill: '#94A3B8', fontSize: 11 }} />
                <YAxis domain={[50, 100]} stroke="#64748B" tick={{ fill: '#94A3B8', fontSize: 11 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0F172A', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }}
                  itemStyle={{ color: '#E2E8F0' }}
                  formatter={(val: any) => [`${val} pts`, 'Score']}
                />
                <Bar dataKey="score" fill="#6366F1" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
            <span>Showing {agents.length} active autonomous coding agents</span>
            <button
              onClick={() => onNavigate('registry')}
              className="text-indigo-400 hover:text-indigo-300 font-medium"
            >
              Register Agent &rarr;
            </button>
          </div>
        </div>
      </div>

      {/* Recent Benchmark Activity Table */}
      <div className="p-5 rounded-xl bg-slate-900/70 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-sm font-semibold text-white">Recent Benchmark Runs</h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Inspecting the latest head-to-head executions and deterministic test suite results.
            </p>
          </div>
          <button
            onClick={() => onNavigate('history')}
            className="text-xs text-indigo-400 hover:text-indigo-300 font-medium flex items-center gap-1"
          >
            <span>All History</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-mono uppercase text-[11px]">
                <th className="py-2.5 px-3">Run ID</th>
                <th className="py-2.5 px-3">Task Challenge</th>
                <th className="py-2.5 px-3">Category</th>
                <th className="py-2.5 px-3">Competing Agents</th>
                <th className="py-2.5 px-3">Winner</th>
                <th className="py-2.5 px-3">Top Score</th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {runs.map((run) => {
                const winnerExec = run.winnerAgentId ? run.executions[run.winnerAgentId] : undefined;
                return (
                  <tr key={run.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-3 font-mono text-slate-400">
                      {run.id}
                    </td>
                    <td className="py-3 px-3 font-medium text-white max-w-xs truncate">
                      {run.taskTitle}
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-400">
                      {run.taskCategory}
                    </td>
                    <td className="py-3 px-3 text-slate-300">
                      <div className="flex items-center gap-1.5">
                        {run.agents.map((aid) => {
                          const ag = agents.find((a) => a.id === aid);
                          return (
                            <span
                              key={aid}
                              className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 font-mono text-[11px]"
                            >
                              {ag?.name || aid}
                            </span>
                          );
                        })}
                      </div>
                    </td>
                    <td className="py-3 px-3 text-indigo-400 font-medium">
                      {winnerExec?.agentName || 'Tied / In Progress'}
                    </td>
                    <td className="py-3 px-3 font-mono font-bold text-emerald-400 tabular-nums">
                      {winnerExec?.evaluationScore?.overall ? `${winnerExec.evaluationScore.overall} pts` : '—'}
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={() => onSelectRun(run)}
                        className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition-colors cursor-pointer"
                      >
                        Inspect Diff
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Quick Launch Task Showcase */}
      <div className="p-5 rounded-xl bg-slate-900/70 border border-slate-800">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h2 className="text-sm font-semibold text-white">Standardized Benchmark Suites</h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Select a pre-configured challenge to launch a multi-agent comparison in the Arena.
            </p>
          </div>
          <button
            onClick={() => onNavigate('tasks')}
            className="text-xs text-indigo-400 hover:text-indigo-300 font-medium"
          >
            Manage All Tasks &rarr;
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {tasks.slice(0, 3).map((task) => (
            <div
              key={task.id}
              className="p-4 rounded-lg bg-slate-950/60 border border-slate-800/80 hover:border-indigo-500/40 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between text-xs text-slate-400 font-mono mb-2">
                  <span className="capitalize">{task.language}</span>
                  <span aria-hidden="true">·</span>
                  <span>{task.timeLimitSec}s limit</span>
                </div>
                <h3 className="text-sm font-semibold text-white line-clamp-2">
                  {task.title}
                </h3>
                <p className="text-xs text-slate-400 mt-1 line-clamp-2">
                  {task.description}
                </p>
              </div>

              <div className="pt-3 mt-3 border-t border-slate-800/80 flex items-center justify-between">
                <span className="text-[11px] text-slate-500 font-mono">
                  {task.testCases.length} deterministic tests
                </span>
                <button
                  onClick={() => onStartBenchmark(task)}
                  className="px-2.5 py-1 rounded bg-indigo-600/20 text-indigo-300 hover:bg-indigo-600 hover:text-white text-xs font-medium transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <Play className="w-3 h-3 fill-current" />
                  <span>Run Arena</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
