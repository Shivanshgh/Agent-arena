/**
 * AgentArena - Core Domain Types
 * Standardized data models for AI Agent Benchmarking
 */

export type AgentIntegrationType = 'http_webhook' | 'docker_container' | 'bifrost_gateway';

export type AgentStatus = 'ready' | 'busy' | 'offline' | 'error';

export interface AgentCapability {
  id: string;
  name: string;
  description: string;
}

export interface AgentAuthConfig {
  type: 'NONE' | 'BEARER_TOKEN' | 'API_KEY' | 'CUSTOM_HEADER';
  hasSecret?: boolean;
  token?: string;
  headerName?: string;
}

export interface ConnectionTestResult {
  success: boolean;
  statusCode?: number;
  latencyMs: number;
  message: string;
  protocolVersion?: string;
  agentVersion?: string;
  capabilities?: string[];
  error?: string;
  timestamp: string;
}

export interface ProtocolTaskRequest {
  protocolVersion: '1.0';
  requestId: string;
  task: {
    taskId: string;
    title: string;
    description: string;
    language: string;
    starterCode?: string;
    input?: any;
    testCases?: any[];
  };
  constraints: {
    timeoutSeconds: number;
    maxOutputSizeBytes: number;
  };
}

export interface ProtocolTaskResponse {
  protocolVersion: '1.0';
  requestId: string;
  status: 'queued' | 'running' | 'completed' | 'failed' | 'timed_out';
  result?: {
    content?: string;
    diff?: string;
    artifacts?: any;
  } | null;
  metrics: {
    durationMs: number;
    inputTokens: number | null;
    outputTokens: number | null;
    memoryBytes?: number | null;
  };
  error?: {
    code?: string;
    message: string;
    details?: any;
  } | null;
  metadata?: Record<string, any>;
}

export interface Agent {
  id: string;
  name: string;
  version: string;
  description: string;
  integrationType: AgentIntegrationType;
  endpointUrl: string;
  healthEndpoint?: string;
  author: string;
  createdAt: string;
  status: AgentStatus;
  capabilities: string[];
  supportedLanguages: string[];
  baseModel: string;
  avgScore: number;
  totalRuns: number;
  lastActive: string;
  lastConnectedAt?: string;
  authConfig?: AgentAuthConfig;
  metadata?: Record<string, any>;
}

export type TaskDifficulty = 'easy' | 'medium' | 'hard' | 'swe_bench';
export type TaskCategory = 'bug_fixing' | 'algorithmic' | 'system_refactor' | 'security' | 'database';

export interface TestCase {
  id: string;
  name: string;
  input: string;
  expectedOutput: string;
  isSecret: boolean;
  timeoutMs: number;
}

export interface BenchmarkTask {
  id: string;
  title: string;
  category: TaskCategory;
  difficulty: TaskDifficulty;
  language: string;
  description: string;
  starterCode: string;
  referenceSolution?: string;
  testCases: TestCase[];
  timeLimitSec: number;
  memoryLimitMb: number;
  createdAt: string;
  tags: string[];
}

export interface ScoringWeights {
  accuracy: number;        // default 40%
  taskCompletion: number;  // default 25%
  reliability: number;     // default 15%
  speed: number;           // default 10%
  costEfficiency: number;  // default 10%
}

export interface ExecutionMetrics {
  durationMs: number;
  inputTokens: number;
  outputTokens: number;
  totalTokens: number;
  estimatedCostUsd: number;
  memoryUsedMb: number;
  testsPassed: number;
  totalTests: number;
  deterministicPassRate: number; // 0 to 100
  aiJudgeScore?: number;          // 0 to 100
}

export type ExecutionStepStatus = 'pending' | 'in_progress' | 'completed' | 'failed';

export interface ExecutionStep {
  name: string;
  description: string;
  status: ExecutionStepStatus;
  durationMs?: number;
}

export interface AgentExecution {
  id: string;
  benchmarkRunId: string;
  agentId: string;
  agentName: string;
  agentVersion: string;
  status: 'pending' | 'running' | 'completed' | 'failed' | 'timeout';
  steps: ExecutionStep[];
  metrics: ExecutionMetrics;
  generatedCode: string;
  unifiedDiff: string;
  stdoutLogs: string[];
  stderrLogs: string[];
  evaluationScore?: {
    overall: number;
    accuracySubscore: number;
    completionSubscore: number;
    reliabilitySubscore: number;
    speedSubscore: number;
    costSubscore: number;
    breakdownExplanation: string;
  };
}

export interface BenchmarkRun {
  id: string;
  taskId: string;
  taskTitle: string;
  taskCategory: TaskCategory;
  startedAt: string;
  completedAt?: string;
  status: 'queued' | 'running' | 'completed' | 'failed';
  agents: string[]; // agent IDs
  executions: Record<string, AgentExecution>;
  scoringWeights: ScoringWeights;
  winnerAgentId?: string;
  summary: string;
}

export interface LeaderboardEntry {
  rank: number;
  agentId: string;
  agentName: string;
  agentVersion: string;
  overallScore: number;
  accuracy: number;
  avgDurationSec: number;
  completionRate: number;
  costEfficiencyScore: number;
  reliabilityRate: number;
  totalRuns: number;
  primaryCategory: string;
  trend: 'up' | 'down' | 'neutral';
}

export interface AIUsageMetrics {
  totalCalls: number;
  totalPromptTokens: number;
  totalCandidateTokens: number;
  cachedRequestsCount: number;
  cacheHitRatePercent: number;
  estimatedCostUsd: number;
  callsByFeature: {
    feature: string;
    calls: number;
    tokens: number;
  }[];
  callsByModel: {
    model: string;
    calls: number;
    tokens: number;
  }[];
  failedCallsCount: number;
  aiJudgeEnabled: boolean;
}

/**
 * Standardized AgentArena Communication Protocol
 * Payloads exchanged between Arena Engine and Agents
 */
export interface AgentTaskDispatchPayload {
  protocolVersion: '1.0';
  benchmarkRunId: string;
  taskId: string;
  taskTitle: string;
  language: string;
  instructions: string;
  starterCode: string;
  constraints: {
    timeoutSec: number;
    memoryLimitMb: number;
    allowedNetwork: boolean;
    readOnlyFiles?: string[];
  };
  environment: {
    os: string;
    runtimeVersion: string;
  };
}

export interface AgentTaskResponsePayload {
  protocolVersion: '1.0';
  status: 'success' | 'failed' | 'timeout' | 'error';
  executionDurationMs: number;
  finalCode: string;
  patchUnifiedDiff?: string;
  tokenUsage?: {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
    modelIdentifier?: string;
  };
  errorMessage?: string;
  toolInvocationsCount?: number;
  metadata?: Record<string, unknown>;
}
