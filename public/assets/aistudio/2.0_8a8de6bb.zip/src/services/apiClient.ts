/**
 * Reusable Frontend API Client Layer for AgentArena
 * Connects frontend views to backend Express REST endpoints
 */

import { Agent, BenchmarkTask, BenchmarkRun, LeaderboardEntry } from '../types';
import { INITIAL_AGENTS, INITIAL_TASKS, INITIAL_BENCHMARK_RUNS } from '../data/mockData';

const BASE_URL = '/api';

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const url = `${BASE_URL}${endpoint}`;
  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  };

  try {
    const response = await fetch(url, { ...options, headers });
    if (!response.ok) {
      const errorBody = await response.json().catch(() => ({}));
      throw new Error(errorBody.message || `API request failed: ${response.status} ${response.statusText}`);
    }
    return await response.json();
  } catch (err: any) {
    console.warn(`[API Client Warning] Failed fetching ${url}:`, err.message);
    throw err;
  }
}

export const apiClient = {
  health: {
    async check(): Promise<{ status: string; uptimeSeconds: number }> {
      return await request('/health');
    },
    async checkDb(): Promise<{ status: string; database: { connected: boolean; provider: string; error?: string } }> {
      return await request('/health/db');
    },
  },

  agents: {
    async list(): Promise<Agent[]> {
      try {
        const data = await request<any[]>('/agents');
        return data.map((a) => ({
          ...a,
          integrationType: (a.integrationType || 'http_webhook').toLowerCase(),
          status: (a.status || 'ready').toLowerCase(),
        }));
      } catch {
        return INITIAL_AGENTS;
      }
    },

    async get(id: string): Promise<Agent> {
      return await request(`/agents/${id}`);
    },

    async create(agentData: Partial<Agent>): Promise<Agent> {
      return await request('/agents', {
        method: 'POST',
        body: JSON.stringify(agentData),
      });
    },

    async update(id: string, agentData: Partial<Agent>): Promise<Agent> {
      return await request(`/agents/${id}`, {
        method: 'PUT',
        body: JSON.stringify(agentData),
      });
    },

    async delete(id: string): Promise<{ success: boolean; message: string }> {
      return await request(`/agents/${id}`, {
        method: 'DELETE',
      });
    },

    async ping(id: string): Promise<{ success: boolean; latencyMs: number; message: string }> {
      return await request(`/agents/${id}/ping`, {
        method: 'POST',
      });
    },

    async testConnection(id: string): Promise<import('../types').ConnectionTestResult> {
      return await request(`/agents/${id}/test`, {
        method: 'POST',
      });
    },

    async executeTask(id: string, taskRequest: import('../types').ProtocolTaskRequest): Promise<import('../types').ProtocolTaskResponse> {
      return await request(`/agents/${id}/execute`, {
        method: 'POST',
        body: JSON.stringify(taskRequest),
      });
    },
  },

  tasks: {
    async list(category?: string, difficulty?: string): Promise<BenchmarkTask[]> {
      try {
        const params = new URLSearchParams();
        if (category && category !== 'all') params.append('category', category);
        if (difficulty && difficulty !== 'all') params.append('difficulty', difficulty);

        const qs = params.toString() ? `?${params.toString()}` : '';
        const data = await request<any[]>(`/tasks${qs}`);
        return data.map((t) => ({
          ...t,
          category: (t.category || 'bug_fixing').toLowerCase(),
          difficulty: (t.difficulty || 'medium').toLowerCase(),
          testCases: t.testCases || t.testCasesJson || [],
          tags: t.tags || [t.category, t.language, t.difficulty],
        }));
      } catch {
        return INITIAL_TASKS;
      }
    },

    async create(taskData: Partial<BenchmarkTask>): Promise<BenchmarkTask> {
      return await request('/tasks', {
        method: 'POST',
        body: JSON.stringify(taskData),
      });
    },

    async delete(id: string): Promise<{ success: boolean; message: string }> {
      return await request(`/tasks/${id}`, {
        method: 'DELETE',
      });
    },
  },

  benchmarks: {
    async list(): Promise<BenchmarkRun[]> {
      try {
        return await request<BenchmarkRun[]>('/benchmarks');
      } catch {
        return INITIAL_BENCHMARK_RUNS;
      }
    },

    async create(runData: any): Promise<BenchmarkRun> {
      return await request('/benchmarks', {
        method: 'POST',
        body: JSON.stringify(runData),
      });
    },
  },

  leaderboard: {
    async get(category?: string): Promise<LeaderboardEntry[]> {
      try {
        const qs = category && category !== 'all' ? `?category=${category}` : '';
        return await request<LeaderboardEntry[]>(`/leaderboard${qs}`);
      } catch {
        return [];
      }
    },
  },

  analytics: {
    async get(): Promise<any> {
      return await request('/analytics');
    },
  },
};
