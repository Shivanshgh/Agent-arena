import fs from 'fs';
import { exec, spawn } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

export interface DockerExecutionOptions {
  image?: string;
  command?: string[];
  code?: string;
  timeoutMs?: number;
  maxOutputSizeBytes?: number;
}

export interface DockerExecutionResult {
  success: boolean;
  exitCode: number;
  stdout: string;
  stderr: string;
  durationMs: number;
  timedOut: boolean;
  isolationApplied: boolean;
  errorMessage?: string;
}

// Pinned secure sandbox images
export const ALLOWED_DOCKER_IMAGES: Record<string, string> = {
  python: 'python:3.11-slim',
  typescript: 'node:20-alpine',
  javascript: 'node:20-alpine',
};

export class DockerExecutor {
  /**
   * Inspects Docker daemon availability in the current container environment
   */
  static async checkAvailability(): Promise<{
    available: boolean;
    status: 'AVAILABLE' | 'BLOCKED_BY_EXTERNAL_INFRASTRUCTURE' | 'DISABLED';
    reason: string;
    version?: string;
  }> {
    // 1. Check if docker socket exists
    const socketPath = process.env.DOCKER_SOCKET || '/var/run/docker.sock';
    const socketExists = fs.existsSync(socketPath);

    if (!socketExists) {
      return {
        available: false,
        status: 'BLOCKED_BY_EXTERNAL_INFRASTRUCTURE',
        reason: 'Docker socket (/var/run/docker.sock) is not accessible in this container environment.',
      };
    }

    // 2. Try pinging docker daemon CLI
    try {
      const { stdout } = await execAsync('docker --version', { timeout: 3000 });
      return {
        available: true,
        status: 'AVAILABLE',
        reason: 'Docker daemon is connected and container isolation is operational.',
        version: stdout.trim(),
      };
    } catch (err: any) {
      return {
        available: false,
        status: 'BLOCKED_BY_EXTERNAL_INFRASTRUCTURE',
        reason: `Docker binary or daemon connection failed: ${err.message}`,
      };
    }
  }

  /**
   * Returns security parameters enforced on any isolated container execution
   */
  static getSecurityProfile(): {
    networkDisabled: boolean;
    nonRootUser: boolean;
    memoryLimit: string;
    cpuLimit: string;
    readOnlyRoot: boolean;
    capDrop: string;
    pidsLimit: number;
  } {
    return {
      networkDisabled: true,
      nonRootUser: true,
      memoryLimit: '512m',
      cpuLimit: '1.0',
      readOnlyRoot: true,
      capDrop: 'ALL',
      pidsLimit: 64,
    };
  }

  /**
   * Executes code inside an isolated Docker sandbox with strict security constraints
   */
  static async executeCode(
    language: string,
    code: string,
    options: DockerExecutionOptions = {}
  ): Promise<DockerExecutionResult> {
    const availability = await this.checkAvailability();
    if (!availability.available) {
      return {
        success: false,
        exitCode: 126,
        stdout: '',
        stderr: availability.reason,
        durationMs: 0,
        timedOut: false,
        isolationApplied: false,
        errorMessage: availability.reason,
      };
    }

    const image = ALLOWED_DOCKER_IMAGES[language.toLowerCase()] || 'node:20-alpine';
    const timeoutMs = options.timeoutMs || 30_000;
    const maxOutputSizeBytes = options.maxOutputSizeBytes || 100_000;

    const startTime = performance.now();

    // Security flags according to Stage 7 specification:
    // --rm: remove container upon exit
    // --network=none: drop all external network access
    // --user=1000:1000: non-root user
    // --cap-drop=ALL: drop all capabilities
    // --memory=512m: memory limit
    // --cpus=1.0: CPU cap
    // --read-only: read-only rootfs
    // --tmpfs: temporary memory mount for script execution
    const dockerArgs = [
      'run',
      '--rm',
      '--network=none',
      '--user=1000:1000',
      '--cap-drop=ALL',
      '--memory=512m',
      '--cpus=1.0',
      '--pids-limit=64',
      '--read-only',
      '--tmpfs=/tmp:rw,noexec,nosuid,size=64m',
      '-i',
      image,
    ];

    if (language.toLowerCase().includes('python')) {
      dockerArgs.push('python3', '-c', code);
    } else {
      dockerArgs.push('node', '-e', code);
    }

    return new Promise((resolve) => {
      let stdout = '';
      let stderr = '';
      let timedOut = false;

      const proc = spawn('docker', dockerArgs, { timeout: timeoutMs });

      const timer = setTimeout(() => {
        timedOut = true;
        proc.kill('SIGKILL');
      }, timeoutMs);

      proc.stdout.on('data', chunk => {
        if (stdout.length < maxOutputSizeBytes) {
          stdout += chunk.toString();
        }
      });

      proc.stderr.on('data', chunk => {
        if (stderr.length < maxOutputSizeBytes) {
          stderr += chunk.toString();
        }
      });

      proc.on('close', code => {
        clearTimeout(timer);
        const durationMs = Math.round(performance.now() - startTime);

        resolve({
          success: code === 0 && !timedOut,
          exitCode: code || 0,
          stdout: stdout.slice(0, maxOutputSizeBytes),
          stderr: stderr.slice(0, maxOutputSizeBytes),
          durationMs,
          timedOut,
          isolationApplied: true,
          errorMessage: timedOut ? `Execution timed out after ${timeoutMs}ms` : undefined,
        });
      });

      proc.on('error', err => {
        clearTimeout(timer);
        resolve({
          success: false,
          exitCode: 1,
          stdout,
          stderr: err.message,
          durationMs: Math.round(performance.now() - startTime),
          timedOut: false,
          isolationApplied: false,
          errorMessage: err.message,
        });
      });
    });
  }
}
