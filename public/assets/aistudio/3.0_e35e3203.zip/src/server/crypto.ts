import crypto from 'crypto';

// Master key derivation: 32 bytes for AES-256-GCM
const rawSecret = process.env.AGENTARENA_SECRET_KEY || process.env.ENCRYPTION_KEY || 'agentarena-default-secure-dev-key-change-in-prod';
const MASTER_KEY = crypto.createHash('sha256').update(rawSecret).digest();

export interface EncryptedPayload {
  encryptedData: string; // hex
  iv: string;           // hex
  tag: string;          // hex
}

/**
 * Encrypts a sensitive credential using AES-256-GCM
 */
export function encryptSecret(plainText: string): EncryptedPayload {
  if (!plainText) {
    throw new Error('Cannot encrypt empty secret');
  }

  const iv = crypto.randomBytes(12); // Standard 96-bit IV for GCM
  const cipher = crypto.createCipheriv('aes-256-gcm', MASTER_KEY, iv);

  let encrypted = cipher.update(plainText, 'utf8', 'hex');
  encrypted += cipher.final('hex');

  const tag = cipher.getAuthTag().toString('hex');

  return {
    encryptedData: encrypted,
    iv: iv.toString('hex'),
    tag,
  };
}

/**
 * Decrypts an AES-256-GCM encrypted credential
 */
export function decryptSecret(payload: EncryptedPayload): string {
  const decipher = crypto.createDecipheriv(
    'aes-256-gcm',
    MASTER_KEY,
    Buffer.from(payload.iv, 'hex')
  );

  decipher.setAuthTag(Buffer.from(payload.tag, 'hex'));

  let decrypted = decipher.update(payload.encryptedData, 'hex', 'utf8');
  decrypted += decipher.final('utf8');

  return decrypted;
}

/**
 * Redacts secrets from headers or error logs
 */
export function redactSecret(secret?: string | null): string {
  if (!secret) return '';
  if (secret.length <= 6) return '••••••';
  return secret.substring(0, 3) + '••••' + secret.substring(secret.length - 2);
}
